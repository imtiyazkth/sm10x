/**
 * SM 10X — Reports Module
 */

import { submitReport, getUserByMemberId } from './db.js';
import { showToast, hideModal, el, showLoading, hideLoading } from './ui.js';

let _reporterUid = null;

export function initReports(uid) {
  _reporterUid = uid;
}

export const REPORT_CATEGORIES = [
  { value: 'abuse',                label: '🔴 Abuse' },
  { value: 'harassment',           label: '🟠 Harassment' },
  { value: 'threat',               label: '🔴 Threat / Violence' },
  { value: 'spam',                 label: '🟡 Spam' },
  { value: 'scam',                 label: '🟠 Scam / Fraud' },
  { value: 'inappropriate_content',label: '🟣 Inappropriate Content' },
  { value: 'other',                label: '⚪ Other' }
];

/** Pre-fill the report modal with the target member ID */
export function openReportModal(targetMemberId = '') {
  const inputEl = el('report-member-id');
  if (inputEl) inputEl.value = targetMemberId;
  const select = el('report-category');
  if (select) {
    select.innerHTML = REPORT_CATEGORIES
      .map(c => `<option value="${c.value}">${c.label}</option>`)
      .join('');
  }
  const descEl = el('report-description');
  if (descEl) descEl.value = '';
  import('./ui.js').then(({ showModal }) => showModal('report'));
}

export async function handleSubmitReport() {
  const memberId    = el('report-member-id')?.value.trim();
  const category    = el('report-category')?.value;
  const description = el('report-description')?.value.trim();

  if (!memberId || !/^\d{8}$/.test(memberId)) {
    showToast('Enter a valid 8-digit Member ID to report.', 'error');
    return;
  }
  if (!category) {
    showToast('Please select a category.', 'error');
    return;
  }

  showLoading('Submitting report…');
  try {
    const target = await getUserByMemberId(memberId);
    if (!target) {
      hideLoading();
      showToast('Member ID not found.', 'error');
      return;
    }
    if (target.uid === _reporterUid) {
      hideLoading();
      showToast('You cannot report yourself.', 'warning');
      return;
    }

    await submitReport({
      reporterUid:    _reporterUid,   // kept private from reportee
      targetMemberId: memberId,
      targetUid:      target.uid,
      category,
      description
    });

    hideLoading();
    hideModal();
    showToast('Report submitted. Thank you for keeping SM 10X safe.', 'success', 4000);
  } catch (err) {
    hideLoading();
    showToast(err.message || 'Failed to submit report.', 'error');
  }
}
