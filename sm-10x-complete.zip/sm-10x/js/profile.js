/**
 * SM 10X — Profile Module
 * View and edit the signed-in user's own profile.
 * Other users cannot see email or mobile.
 */

import { auth } from './config.js';
import { updateProfile, updatePassword, EmailAuthProvider, reauthenticateWithCredential }
  from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';

import { getUser, updateUser }             from './db.js';
import { uploadProfilePhoto }              from './cloudinary.js';
import { resendVerification, reloadUser }  from './auth.js';
import {
  showToast, avatarHTML, el, setText, showLoading,
  hideLoading, validateEmail, validateMobile, escapeHTML
} from './ui.js';

let _uid     = null;
let _profile = null;

// ─── Load & render profile ─────────────────────────────────────
export async function loadProfile(uid) {
  _uid = uid;
  const profile = await getUser(uid);
  if (!profile) return;
  _profile = profile;
  _renderProfile(profile);
}

function _renderProfile(p) {
  // Avatar
  const avatarEl = el('profile-avatar-img');
  if (avatarEl) avatarEl.innerHTML = avatarHTML(p.displayName, p.photoURL, 90);

  // Fields (owner sees everything)
  setText('profile-display-name', p.displayName || '—');
  setText('profile-member-id',    p.memberId || '—');
  setText('profile-email',        p.email    || '—');

  const mobileEl = el('profile-mobile');
  if (mobileEl) {
    mobileEl.textContent = p.mobile ? p.mobile : 'Not set (optional)';
    mobileEl.style.color = p.mobile ? '' : 'var(--text-secondary)';
  }

  // Email verification banner
  const verBanner = el('verify-email-banner');
  const verBtn    = el('resend-verify-btn');
  if (verBanner) verBanner.style.display = p.emailVerified ? 'none' : 'flex';
  if (verBtn)    verBtn.style.display    = p.emailVerified ? 'none' : 'inline-flex';

  // Pre-fill edit inputs
  const nameInput   = el('edit-display-name');
  const mobileInput = el('edit-mobile');
  if (nameInput)   nameInput.value   = p.displayName || '';
  if (mobileInput) mobileInput.value = p.mobile || '';
}

// ─── Edit Display Name ─────────────────────────────────────────
export async function saveDisplayName() {
  const input = el('edit-display-name');
  const name  = input?.value.trim();
  if (!name)        { showToast('Name cannot be empty.', 'error'); return; }
  if (name.length > 40) { showToast('Name too long (max 40 chars).', 'error'); return; }

  showLoading('Saving…');
  try {
    await updateProfile(auth.currentUser, { displayName: name });
    await updateUser(_uid, { displayName: name });
    _profile.displayName = name;
    _renderProfile(_profile);
    hideLoading();
    showToast('Display name updated.', 'success');
  } catch (err) {
    hideLoading();
    showToast(err.message || 'Update failed.', 'error');
  }
}

// ─── Edit Mobile ──────────────────────────────────────────────
export async function saveMobile() {
  const input  = el('edit-mobile');
  const mobile = input?.value.trim();
  if (mobile && !validateMobile(mobile)) {
    showToast('Enter a valid mobile number or leave it empty.', 'error');
    return;
  }
  showLoading('Saving…');
  try {
    await updateUser(_uid, { mobile: mobile || null });
    _profile.mobile = mobile || null;
    _renderProfile(_profile);
    hideLoading();
    showToast('Mobile number ' + (mobile ? 'saved.' : 'removed.'), 'success');
  } catch (err) {
    hideLoading();
    showToast(err.message || 'Update failed.', 'error');
  }
}

// ─── Upload profile photo ─────────────────────────────────────
export async function handleProfilePhotoChange(file) {
  if (!file) return;
  try {
    const { url } = await uploadProfilePhoto(file, _uid);
    await updateProfile(auth.currentUser, { photoURL: url });
    await updateUser(_uid, { photoURL: url });
    _profile.photoURL = url;
    _renderProfile(_profile);
    showToast('Profile photo updated.', 'success');
  } catch (err) {
    showToast(err.message || 'Photo upload failed.', 'error');
  }
}

// ─── Change password ──────────────────────────────────────────
export async function handleChangePassword() {
  const currentPass = el('current-password')?.value;
  const newPass     = el('new-password')?.value;
  const confirmPass = el('confirm-password')?.value;

  if (!currentPass || !newPass || !confirmPass) {
    showToast('All password fields are required.', 'error'); return;
  }
  if (newPass !== confirmPass) {
    showToast('New passwords do not match.', 'error'); return;
  }
  if (newPass.length < 6) {
    showToast('Password must be at least 6 characters.', 'error'); return;
  }

  showLoading('Updating password…');
  try {
    const user       = auth.currentUser;
    const credential = EmailAuthProvider.credential(user.email, currentPass);
    await reauthenticateWithCredential(user, credential);
    await updatePassword(user, newPass);
    hideLoading();
    showToast('Password changed successfully.', 'success');

    // Clear fields
    ['current-password','new-password','confirm-password'].forEach(id => {
      const inp = el(id); if (inp) inp.value = '';
    });
  } catch (err) {
    hideLoading();
    const map = {
      'auth/wrong-password':     'Current password is incorrect.',
      'auth/too-many-requests':  'Too many attempts. Please wait.',
      'auth/weak-password':      'New password is too weak.'
    };
    showToast(map[err.code] || err.message || 'Password change failed.', 'error');
  }
}

// ─── Resend verification ──────────────────────────────────────
export async function handleResendVerification() {
  try {
    await resendVerification();
  } catch (err) {
    showToast(err.message || 'Failed to send verification email.', 'error');
  }
}

// ─── Check verification status (manual refresh) ───────────────
export async function checkEmailVerification() {
  showLoading('Checking…');
  try {
    const user = await reloadUser();
    if (user?.emailVerified) {
      await updateUser(_uid, { emailVerified: true });
      _profile.emailVerified = true;
      _renderProfile(_profile);
      showToast('Email verified! You can now send messages and make calls.', 'success', 5000);
    } else {
      showToast('Email not yet verified. Check your inbox.', 'info');
    }
    hideLoading();
  } catch (err) {
    hideLoading();
    showToast('Could not check verification status.', 'error');
  }
}

export function getProfile() { return _profile; }
