/**
 * SM 10X — Presence Module
 * Manages online/offline status and last-seen timestamps.
 * Uses Firestore heartbeat pattern (works without RTDB).
 */

import {
  doc, updateDoc, onSnapshot, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

import { db, APP } from './config.js';

let _heartbeatTimer   = null;
let _activeListeners  = {};
let _myUid            = null;

// ─── Start presence for the signed-in user ────────────────────
export async function startPresence(uid) {
  _myUid = uid;
  await _setOnline(uid);

  // Heartbeat every 30 s so Firestore can track last-seen
  _heartbeatTimer = setInterval(() => _setOnline(uid), APP.presenceMs);

  // Go offline when the tab/window loses focus or closes
  window.addEventListener('beforeunload',  _handleOffline);
  document.addEventListener('visibilitychange', _handleVisibility);
}

export async function stopPresence() {
  if (!_myUid) return;
  clearInterval(_heartbeatTimer);
  window.removeEventListener('beforeunload',     _handleOffline);
  document.removeEventListener('visibilitychange', _handleVisibility);
  await _setOffline(_myUid);
  _myUid = null;
}

async function _setOnline(uid) {
  try {
    await updateDoc(doc(db, 'users', uid), {
      isOnline: true,
      lastSeen: serverTimestamp()
    });
  } catch (_) {}
}

async function _setOffline(uid) {
  try {
    await updateDoc(doc(db, 'users', uid), {
      isOnline: false,
      lastSeen: serverTimestamp()
    });
  } catch (_) {}
}

function _handleOffline() { if (_myUid) _setOffline(_myUid); }

function _handleVisibility() {
  if (!_myUid) return;
  if (document.hidden) _setOffline(_myUid);
  else                 _setOnline(_myUid);
}

// ─── Watch another user's presence ────────────────────────────
/**
 * @param {string}   uid        — UID to watch
 * @param {Function} callback   — called with { isOnline, lastSeen }
 * @returns unsubscribe function
 */
export function watchPresence(uid, callback) {
  if (_activeListeners[uid]) _activeListeners[uid]();   // unsub existing
  const unsub = onSnapshot(doc(db, 'users', uid), snap => {
    if (!snap.exists()) return;
    const { isOnline, lastSeen } = snap.data();
    callback({ isOnline: !!isOnline, lastSeen });
  });
  _activeListeners[uid] = unsub;
  return unsub;
}

export function stopWatchingPresence(uid) {
  if (_activeListeners[uid]) {
    _activeListeners[uid]();
    delete _activeListeners[uid];
  }
}

export function stopAllPresenceListeners() {
  Object.values(_activeListeners).forEach(fn => fn());
  _activeListeners = {};
}
