/**
 * SM 10X — UI Utilities
 * Screen navigation, modals, toasts, loaders, formatting helpers.
 * No Firebase imports — pure DOM.
 */

// ─── Screen & Tab State ──────────────────────────────────────
let _currentScreen = 'auth';
let _currentTab    = 'chats';
let _screenHistory = [];

/** Show a top-level screen and hide all others */
export function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(`screen-${screenId}`);
  if (target) {
    target.classList.add('active');
    if (_currentScreen !== screenId) _screenHistory.push(_currentScreen);
    _currentScreen = screenId;
  }
}

/** Navigate back one step in history */
export function goBack() {
  const prev = _screenHistory.pop();
  if (prev) showScreen(prev);
}

/** Show a tab within the main screen */
export function showTab(tabId) {
  document.querySelectorAll('.tab-page').forEach(t => t.classList.remove('active'));
  const tab = document.getElementById(`tab-${tabId}`);
  if (tab) tab.classList.add('active');

  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const navBtn = document.querySelector(`.nav-btn[data-tab="${tabId}"]`);
  if (navBtn) navBtn.classList.add('active');

  _currentTab = tabId;
}

export function currentScreen() { return _currentScreen; }
export function currentTab()    { return _currentTab;    }

// ─── Modal ───────────────────────────────────────────────────
export function showModal(modalId) {
  const overlay = document.getElementById('modal-overlay');
  const modal   = document.getElementById(`modal-${modalId}`);
  if (!overlay || !modal) return;
  document.querySelectorAll('.modal').forEach(m => m.classList.remove('active'));
  overlay.classList.add('active');
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

export function hideModal() {
  const overlay = document.getElementById('modal-overlay');
  if (overlay) overlay.classList.remove('active');
  document.querySelectorAll('.modal').forEach(m => m.classList.remove('active'));
  document.body.style.overflow = '';
}

// Close modal on overlay click
document.addEventListener('DOMContentLoaded', () => {
  const overlay = document.getElementById('modal-overlay');
  if (overlay) {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) hideModal();
    });
  }
});

// ─── Toast ───────────────────────────────────────────────────
const _toasts = [];

export function showToast(message, type = 'info', durationMs = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span>
                     <span class="toast-msg">${message}</span>`;

  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));

  const timer = setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 350);
  }, durationMs);
  _toasts.push({ toast, timer });
}

// ─── Loading Overlay ─────────────────────────────────────────
let _loadingCount = 0;

export function showLoading(msg = 'Please wait…') {
  _loadingCount++;
  const el = document.getElementById('loading-overlay');
  const txt = document.getElementById('loading-text');
  if (el)  el.classList.add('active');
  if (txt) txt.textContent = msg;
}

export function hideLoading() {
  _loadingCount = Math.max(0, _loadingCount - 1);
  if (_loadingCount === 0) {
    const el = document.getElementById('loading-overlay');
    if (el) el.classList.remove('active');
  }
}

// ─── Time / Date Formatting ───────────────────────────────────
export function formatTime(timestamp) {
  if (!timestamp) return '';
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function formatTimestamp(timestamp) {
  if (!timestamp) return '';
  const date  = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const now   = new Date();
  const diffMs = now - date;
  const diffD  = Math.floor(diffMs / 86400000);

  if (diffD === 0) return formatTime(timestamp);
  if (diffD === 1) return 'Yesterday';
  if (diffD  <  7) return date.toLocaleDateString([], { weekday: 'short' });
  return date.toLocaleDateString([], { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatLastSeen(timestamp) {
  if (!timestamp) return 'Never';
  const date  = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  const diffMs = Date.now() - date;
  const mins   = Math.floor(diffMs / 60000);
  if (mins < 1)   return 'Just now';
  if (mins < 60)  return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs  < 24)  return `${hrs}h ago`;
  return date.toLocaleDateString([], { day: '2-digit', month: 'short' });
}

export function formatCallDuration(seconds) {
  const m = Math.floor(seconds / 60).toString().padStart(2,'0');
  const s = (seconds % 60).toString().padStart(2,'0');
  return `${m}:${s}`;
}

// ─── Avatar Helpers ───────────────────────────────────────────
const AVATAR_COLORS = [
  '#7c3aed','#ec4899','#f59e0b','#10b981',
  '#3b82f6','#ef4444','#06b6d4','#8b5cf6'
];

export function getAvatarColor(text) {
  let hash = 0;
  for (const ch of String(text)) hash = (hash * 31 + ch.charCodeAt(0)) & 0xffffffff;
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

export function avatarHTML(name, photoURL, size = 44) {
  if (photoURL) {
    return `<img src="${photoURL}" alt="${escapeHTML(name)}"
                 style="width:${size}px;height:${size}px;border-radius:50%;object-fit:cover;"
                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
            <span class="avatar-initials" style="display:none;width:${size}px;height:${size}px;
                  font-size:${Math.round(size*0.4)}px;background:${getAvatarColor(name)};">
              ${initials(name)}
            </span>`;
  }
  return `<span class="avatar-initials" style="width:${size}px;height:${size}px;
                font-size:${Math.round(size*0.4)}px;background:${getAvatarColor(name)};">
            ${initials(name)}
          </span>`;
}

function initials(name) {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return name.substring(0, 2).toUpperCase();
}

// ─── Security helpers ─────────────────────────────────────────
export function escapeHTML(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ─── DOM helpers ──────────────────────────────────────────────
export function el(id) { return document.getElementById(id); }

export function setText(id, text) {
  const node = el(id);
  if (node) node.textContent = text;
}

export function setHTML(id, html) {
  const node = el(id);
  if (node) node.innerHTML = html;
}

export function show(id) {
  const node = el(id); if (node) node.style.display = '';
}

export function hide(id) {
  const node = el(id); if (node) node.style.display = 'none';
}

export function toggleClass(id, cls, force) {
  const node = el(id);
  if (node) node.classList.toggle(cls, force);
}

export function scrollBottom(id) {
  const node = el(id);
  if (node) node.scrollTop = node.scrollHeight;
}

// ─── Input validation ─────────────────────────────────────────
export function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validateMobile(mobile) {
  return !mobile || /^[\+\d\s\-\(\)]{7,20}$/.test(mobile);
}

// ─── Badge ────────────────────────────────────────────────────
export function updateBadge(elementId, count) {
  const el2 = document.getElementById(elementId);
  if (!el2) return;
  if (count > 0) {
    el2.textContent = count > 99 ? '99+' : count;
    el2.style.display = 'flex';
  } else {
    el2.style.display = 'none';
  }
}
