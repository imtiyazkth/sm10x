/**
 * SM 10X — WebRTC Calling Module
 * Browser-based audio/video calls with Firestore signaling.
 * Supports: start call, accept, reject, end, mute, camera toggle,
 *           switch camera (mobile), timer display.
 */

import { WEBRTC_CONFIG, APP } from './config.js';
import {
  createSignalDoc, updateSignalDoc, getSignalDoc,
  listenSignalDoc, addIceCandidate, listenIceCandidates,
  logAdminAction
} from './db.js';
import {
  showScreen, showModal, hideModal, showToast,
  el, setText, formatCallDuration
} from './ui.js';

// ─── State ────────────────────────────────────────────────────
let _pc             = null;   // RTCPeerConnection
let _localStream    = null;
let _remoteStream   = null;
let _callId         = null;
let _myUid          = null;
let _myProfile      = null;
let _partnerId      = null;
let _partnerProfile = null;
let _callType       = null;   // 'audio' | 'video'
let _isCaller       = false;
let _isMuted        = false;
let _isCameraOff    = false;
let _facingMode     = 'user'; // 'user' (front) | 'environment' (back)
let _callTimer      = null;
let _callSeconds    = 0;
let _callUnsubFn    = null;   // Firestore signal listener
let _incomingCallUnsubFn = null;

// ─── Initialise ───────────────────────────────────────────────
export function initCalls(uid, profile) {
  _myUid     = uid;
  _myProfile = profile;
  _listenIncomingCalls();
}

export function destroyCalls() {
  _incomingCallUnsubFn?.();
  endCall();
  _myUid = null;
}

// ─── Listen for incoming calls ────────────────────────────────
import {
  collection, query, where, onSnapshot, orderBy, limit
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
import { db } from './config.js';

function _listenIncomingCalls() {
  if (!_myUid) return;
  const q = query(
    collection(db, 'calls'),
    where('receiverId', '==', _myUid),
    where('status', '==', 'ringing')
  );
  _incomingCallUnsubFn = onSnapshot(q, snap => {
    snap.docChanges().forEach(change => {
      if (change.type === 'added') {
        const call = { id: change.doc.id, ...change.doc.data() };
        _showIncomingCallUI(call);
      }
    });
  });
}

function _showIncomingCallUI(call) {
  // Don't show if already in a call
  if (_callId) return;

  el('incoming-call-name').textContent  = call.callerName   || 'Unknown Member';
  el('incoming-call-id').textContent    = `ID: ${call.callerMemberId || ''}`;
  el('incoming-call-type').textContent  = call.type === 'video' ? '📹 Video Call' : '📞 Audio Call';

  // Store for accept/reject
  window._pendingCall = call;
  showModal('incoming-call');
}

// ─── Start a call ─────────────────────────────────────────────
export async function startCall(partnerUser, type) {
  if (_callId) { showToast('Already in a call.', 'warning'); return; }
  if (!partnerUser?.isOnline) {
    showToast('Member is offline. Calls only work when online.', 'warning');
    return;
  }

  _callType       = type;
  _isCaller       = true;
  _partnerId      = partnerUser.uid;
  _partnerProfile = partnerUser;
  _callId         = `${_myUid}_${partnerUser.uid}_${Date.now()}`;

  try {
    await _getLocalMedia();
    await _setupPeerConnection();

    // Create the offer
    const offer = await _pc.createOffer();
    await _pc.setLocalDescription(offer);

    // Save signal doc
    await createSignalDoc(_callId, {
      callId:          _callId,
      callerId:        _myUid,
      receiverId:      partnerUser.uid,
      callerName:      _myProfile.displayName || '',
      callerMemberId:  _myProfile.memberId,
      receiverMemberId: partnerUser.memberId,
      type,
      status:          'ringing',
      offer:           { sdp: offer.sdp, type: offer.type },
      answer:          null
    });

    // Collect local ICE candidates
    _pc.onicecandidate = async e => {
      if (e.candidate) {
        await addIceCandidate(_callId, 'offerCandidates', e.candidate.toJSON());
      }
    };

    // Listen for answer
    _callUnsubFn = listenSignalDoc(_callId, async signal => {
      if (signal.status === 'rejected') { _handleCallRejected(); return; }
      if (signal.status === 'ended')    { endCall(); return; }
      if (signal.answer && !_pc.remoteDescription) {
        const answer = new RTCSessionDescription(signal.answer);
        await _pc.setRemoteDescription(answer);
        _startCallTimer();
      }
    });

    // Listen for ICE candidates from callee
    listenIceCandidates(_callId, 'answerCandidates', async cand => {
      try { await _pc.addIceCandidate(new RTCIceCandidate(cand)); } catch (_) {}
    });

    _showCallScreen(partnerUser.displayName || 'Member', type);
    _scheduleCallTimeout();

  } catch (err) {
    console.error('startCall:', err);
    showToast(err.message || 'Call failed to start.', 'error');
    endCall();
  }
}

// ─── Accept incoming call ─────────────────────────────────────
export async function acceptCall() {
  const call = window._pendingCall;
  if (!call) return;
  hideModal();

  _callId         = call.id;
  _callType       = call.type;
  _isCaller       = false;
  _partnerId      = call.callerId;

  try {
    await _getLocalMedia();
    await _setupPeerConnection();

    const signal = await getSignalDoc(_callId);
    if (!signal?.offer) { showToast('Call signal lost.', 'error'); return; }

    // Set remote offer
    await _pc.setRemoteDescription(new RTCSessionDescription(signal.offer));

    // Collect local ICE candidates
    _pc.onicecandidate = async e => {
      if (e.candidate) {
        await addIceCandidate(_callId, 'answerCandidates', e.candidate.toJSON());
      }
    };

    // Create and send answer
    const answer = await _pc.createAnswer();
    await _pc.setLocalDescription(answer);
    await updateSignalDoc(_callId, {
      answer: { sdp: answer.sdp, type: answer.type },
      status: 'active'
    });

    // Listen for ICE candidates from caller
    listenIceCandidates(_callId, 'offerCandidates', async cand => {
      try { await _pc.addIceCandidate(new RTCIceCandidate(cand)); } catch (_) {}
    });

    // Listen for call end
    _callUnsubFn = listenSignalDoc(_callId, signal => {
      if (signal.status === 'ended') endCall();
    });

    _showCallScreen(call.callerName || 'Member', call.type);
    _startCallTimer();
    window._pendingCall = null;

  } catch (err) {
    console.error('acceptCall:', err);
    showToast('Failed to accept call.', 'error');
    endCall();
  }
}

// ─── Reject incoming call ─────────────────────────────────────
export async function rejectCall() {
  const call = window._pendingCall;
  if (!call) { hideModal(); return; }
  hideModal();
  try {
    await updateSignalDoc(call.id, { status: 'rejected' });
  } catch (_) {}
  window._pendingCall = null;
}

// ─── End active call ──────────────────────────────────────────
export async function endCall() {
  try {
    if (_callId) await updateSignalDoc(_callId, { status: 'ended' });
  } catch (_) {}

  _callUnsubFn?.();
  clearInterval(_callTimer);
  _localStream?.getTracks().forEach(t => t.stop());
  _remoteStream?.getTracks().forEach(t => t.stop());
  _pc?.close();

  _pc = _localStream = _remoteStream = _callId = null;
  _isCaller = _isMuted = _isCameraOff = false;
  _callSeconds = 0;
  window._pendingCall = null;

  // Go back to previous screen
  if (el('screen-call')?.classList.contains('active')) {
    showScreen('main');
  }
}

// ─── Mute / Camera / Switch Camera ────────────────────────────
export function toggleMute() {
  if (!_localStream) return;
  _isMuted = !_isMuted;
  _localStream.getAudioTracks().forEach(t => { t.enabled = !_isMuted; });
  const btn = el('call-mute-btn');
  if (btn) {
    btn.textContent = _isMuted ? '🔇' : '🎤';
    btn.classList.toggle('active', _isMuted);
  }
}

export function toggleCamera() {
  if (!_localStream || _callType !== 'video') return;
  _isCameraOff = !_isCameraOff;
  _localStream.getVideoTracks().forEach(t => { t.enabled = !_isCameraOff; });
  const btn = el('call-cam-btn');
  if (btn) {
    btn.textContent = _isCameraOff ? '📷' : '🎥';
    btn.classList.toggle('active', _isCameraOff);
  }
}

export async function switchCamera() {
  if (!_localStream || _callType !== 'video') return;
  _facingMode = _facingMode === 'user' ? 'environment' : 'user';
  try {
    const newStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: _facingMode }, audio: true
    });
    const newTrack = newStream.getVideoTracks()[0];
    const sender   = _pc?.getSenders().find(s => s.track?.kind === 'video');
    if (sender) await sender.replaceTrack(newTrack);

    // Replace local video preview
    _localStream.getVideoTracks().forEach(t => t.stop());
    const localVideo = el('local-video');
    if (localVideo) localVideo.srcObject = newStream;
    _localStream = newStream;
  } catch (err) {
    showToast('Camera switch failed.', 'error');
  }
}

// ─── Private helpers ──────────────────────────────────────────
async function _getLocalMedia() {
  const constraints = _callType === 'video'
    ? { video: { facingMode: 'user' }, audio: true }
    : { audio: true };
  _localStream = await navigator.mediaDevices.getUserMedia(constraints);

  const localVideo = el('local-video');
  if (localVideo) {
    localVideo.srcObject = _localStream;
    localVideo.muted = true;
    localVideo.play().catch(() => {});
  }
}

async function _setupPeerConnection() {
  _pc = new RTCPeerConnection(WEBRTC_CONFIG);

  // Add local tracks
  _localStream.getTracks().forEach(track => {
    _pc.addTrack(track, _localStream);
  });

  // Handle remote stream
  _remoteStream = new MediaStream();
  _pc.ontrack = e => {
    e.streams[0]?.getTracks().forEach(t => _remoteStream.addTrack(t));
    const remoteVideo = el('remote-video');
    const remoteAudio = el('remote-audio');
    if (remoteVideo) remoteVideo.srcObject = _remoteStream;
    if (remoteAudio) remoteAudio.srcObject = _remoteStream;
  };

  _pc.onconnectionstatechange = () => {
    const stateEl = el('call-state-label');
    const state   = _pc.connectionState;
    if (stateEl) stateEl.textContent = _connectionLabel(state);
    if (state === 'failed' || state === 'closed') endCall();
  };
}

function _connectionLabel(state) {
  const map = {
    connecting: 'Connecting…',
    connected:  'Connected',
    disconnected: 'Reconnecting…',
    failed:     'Connection failed',
    closed:     'Call ended'
  };
  return map[state] || state;
}

function _showCallScreen(partnerName, type) {
  setText('call-partner-name', partnerName);
  setText('call-type-label',   type === 'video' ? 'Video Call' : 'Audio Call');
  setText('call-state-label',  'Ringing…');

  // Show/hide video elements
  const videoSection = el('call-video-section');
  if (videoSection) videoSection.style.display = type === 'video' ? 'block' : 'none';

  const switchBtn = el('call-switch-cam-btn');
  if (switchBtn) switchBtn.style.display = type === 'video' ? 'flex' : 'none';

  const camBtn = el('call-cam-btn');
  if (camBtn) camBtn.style.display = type === 'video' ? 'flex' : 'none';

  showScreen('call');
}

function _startCallTimer() {
  clearInterval(_callTimer);
  _callSeconds = 0;
  setText('call-state-label', '00:00');
  _callTimer = setInterval(() => {
    _callSeconds++;
    setText('call-state-label', formatCallDuration(_callSeconds));
  }, 1000);
}

function _scheduleCallTimeout() {
  setTimeout(() => {
    if (_callId && _isCaller && !_pc?.remoteDescription) {
      showToast('No answer. Call timed out.', 'info');
      endCall();
    }
  }, APP.callTimeoutMs);
}

function _handleCallRejected() {
  showToast('Call was rejected.', 'info');
  endCall();
}
