/**
 * SM 10X — Main Application Entry Point
 * Wires all modules together.  Handles auth-state routing
 * and attaches every UI event listener.
 */

import { auth, APP }               from './config.js';
import { onAuthChange, login, register,
         resetPassword, logout,
         authErrorMsg }            from './auth.js';
import { getUser, updateUser }     from './db.js';
import { startPresence,
         stopPresence }            from './presence.js';
import { initMessaging,
         destroyMessaging,
         sendTextMessage,
         startChatByMemberId,
         sendImageMessage,
         startVoiceRecording,
         stopVoiceRecording }      from './messaging.js';
import { initContacts, destroyContacts,
         handleAddContact }        from './contacts.js';
import { initCalls, destroyCalls,
         startCall, acceptCall,
         rejectCall, endCall,
         toggleMute, toggleCamera,
         switchCamera }            from './calls.js';
import { initReports, openReportModal,
         handleSubmitReport }      from './reports.js';
import { isAdmin, initAdmin,
         destroyAdmin }            from './admin.js';
import { loadProfile, saveDisplayName,
         saveMobile, handleProfilePhotoChange,
         handleChangePassword,
         handleResendVerification,
         checkEmailVerification,
         getProfile }              from './profile.js';
import {
  showScreen, showTab, showModal, hideModal,
  showToast, showLoading, hideLoading,
  el, validateEmail, scrollBottom
} from './ui.js';

// ─── Boot ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  _attachStaticListeners();
  _startAuthListener();
});

// ─── Auth State ───────────────────────────────────────────────
let _uid          = null;
let _profile      = null;
let _isVerified   = false;

function _startAuthListener() {
  onAuthChange(async user => {
    if (user) {
      _uid = user.uid;

      // Attempt to load Firestore profile
      let profile = await getUser(user.uid);

      // ★ Fallback: if Firestore doc is missing (race condition / network blip),
      //   recreate it using data already on the Auth object.
      if (!profile) {
        showToast('Setting up your profile…', 'info', 4000);
        const { createUserDocument } = await import('./auth.js');
        await createUserDocument(user.uid, {
          displayName: user.displayName || '',
          email:       user.email || '',
          mobile:      null
        });
        profile = await getUser(user.uid);
      }

      if (!profile) {
        showToast('Profile could not be created. Please sign out and try again.', 'error', 8000);
        return;
      }

      _profile    = profile;
      _isVerified = user.emailVerified;

      // Sync emailVerified flag to Firestore
      if (user.emailVerified && !profile.emailVerified) {
        await updateUser(user.uid, { emailVerified: true });
      }

      await startPresence(user.uid);
      initMessaging(user.uid, profile);
      initContacts(user.uid);
      initCalls(user.uid, profile);
      initReports(user.uid);
      if (isAdmin(user.uid)) initAdmin(user.uid);

      await loadProfile(user.uid);
      _updateNavForRole(user.uid);

      showScreen('main');
      showTab('chats');

    } else {
      // Signed out — clean up
      _uid = null; _profile = null; _isVerified = false;
      stopPresence();
      destroyMessaging();
      destroyContacts();
      destroyCalls();
      destroyAdmin();
      showScreen('auth');
      showTab_auth('login');
    }
  });
}

// ─── Auth Tab Switch ──────────────────────────────────────────
function showTab_auth(tab) {
  ['login','register','forgot'].forEach(t => {
    const pane = el(`auth-${t}-pane`);
    if (pane) pane.style.display = t === tab ? 'flex' : 'none';
  });
}

// ─── Nav roles ────────────────────────────────────────────────
function _updateNavForRole(uid) {
  const adminLink = el('nav-admin');
  if (adminLink) adminLink.style.display = isAdmin(uid) ? 'flex' : 'none';
}

// ─── Verified-only guard ──────────────────────────────────────
function requireVerified(action) {
  if (!_isVerified) {
    showToast('Please verify your email first. Check your inbox.', 'warning', 4000);
    return false;
  }
  return true;
}

// ─── ALL event listeners ──────────────────────────────────────
function _attachStaticListeners() {

  // ── Auth form toggles ────────────────────────────────────────
  on('show-login-btn',    () => showTab_auth('login'));
  on('show-register-btn', () => showTab_auth('register'));
  on('show-forgot-btn',   () => showTab_auth('forgot'));
  on('back-to-login-btn', () => showTab_auth('login'));

  // ── Login ────────────────────────────────────────────────────
  on('login-btn', async () => {
    const email    = val('login-email');
    const password = val('login-password');
    if (!email || !password) { showToast('Enter email and password.','error'); return; }
    if (!validateEmail(email)) { showToast('Invalid email format.','error'); return; }
    try {
      await login({ email, password });
    } catch (err) {
      showToast(authErrorMsg(err), 'error');
    }
  });

  // ── Register ─────────────────────────────────────────────────
  on('register-btn', async () => {
    const displayName = val('reg-name').trim();
    const email       = val('reg-email').trim();
    const password    = val('reg-password');
    const mobile      = val('reg-mobile').trim();   // optional

    if (!displayName) { showToast('Enter your display name.','error'); return; }
    if (!validateEmail(email)) { showToast('Enter a valid email.','error'); return; }
    if (password.length < 6)  { showToast('Password must be at least 6 characters.','error'); return; }

    try {
      const { memberId } = await register({ displayName, email, password, mobile });
      el('reg-name').value = el('reg-email').value =
      el('reg-password').value = el('reg-mobile').value = '';
    } catch (err) {
      showToast(authErrorMsg(err), 'error');
    }
  });

  // ── Forgot password ───────────────────────────────────────────
  on('forgot-btn', async () => {
    const email = val('forgot-email').trim();
    if (!validateEmail(email)) { showToast('Enter a valid email.','error'); return; }
    try {
      await resetPassword(email);
    } catch (err) {
      showToast(authErrorMsg(err), 'error');
    }
  });

  // ── Logout ────────────────────────────────────────────────────
  on('logout-btn', async () => {
    if (confirm('Sign out of SM 10X?')) await logout();
  });

  // ── Bottom nav ────────────────────────────────────────────────
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => showTab(btn.dataset.tab));
  });

  // ── New chat search ───────────────────────────────────────────
  on('new-chat-btn', () => showModal('new-chat'));
  on('search-member-btn', async () => {
    if (!requireVerified()) return;
    const memberId = val('search-member-id');
    hideModal();
    await startChatByMemberId(memberId);
    el('search-member-id').value = '';
  });

  // ── Chat input / send / voice ─────────────────────────────────
  on('send-msg-btn', async () => {
    if (!requireVerified()) return;
    await sendTextMessage();
  });

  const chatInput = el('chat-input');
  if (chatInput) {
    chatInput.addEventListener('keydown', async e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (!requireVerified()) return;
        await sendTextMessage();
      }
    });
    // Auto-grow
    chatInput.addEventListener('input', () => {
      chatInput.style.height = 'auto';
      chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    });
  }

  // Image pick
  on('attach-img-btn', () => {
    if (!requireVerified()) return;
    el('image-file-input')?.click();
  });
  on('image-file-input', async e => {
    const file = e.target.files?.[0];
    if (file) { await sendImageMessage(file); e.target.value = ''; }
  }, 'change');

  // Voice note
  let _voiceHeld = false;
  const voiceBtn = el('voice-btn');
  if (voiceBtn) {
    const startRec = async () => {
      if (!requireVerified()) return;
      _voiceHeld = true;
      await startVoiceRecording();
    };
    const stopRec = () => {
      if (_voiceHeld) { _voiceHeld = false; stopVoiceRecording(); }
    };
    voiceBtn.addEventListener('mousedown',  startRec);
    voiceBtn.addEventListener('touchstart', startRec, { passive: true });
    voiceBtn.addEventListener('mouseup',    stopRec);
    voiceBtn.addEventListener('touchend',   stopRec);
    voiceBtn.addEventListener('mouseleave', stopRec);
  }

  // ── Call buttons in chat header ───────────────────────────────
  on('audio-call-btn', () => {
    if (!requireVerified()) return;
    import('./messaging.js').then(({ getActivePartner }) => {
      const partner = getActivePartner();
      if (partner) startCall(partner, 'audio');
    });
  });
  on('video-call-btn', () => {
    if (!requireVerified()) return;
    import('./messaging.js').then(({ getActivePartner }) => {
      const partner = getActivePartner();
      if (partner) startCall(partner, 'video');
    });
  });

  // ── Report from chat header ───────────────────────────────────
  on('report-member-btn', () => {
    import('./messaging.js').then(({ getActivePartner }) => {
      const partner = getActivePartner();
      openReportModal(partner?.memberId || '');
    });
  });

  // ── Back buttons ─────────────────────────────────────────────
  on('chat-back-btn',    () => { showScreen('main'); showTab('chats'); });
  on('call-end-btn',     () => endCall());
  on('profile-back-btn', () => { showScreen('main'); showTab('chats'); });
  on('admin-back-btn',   () => { showScreen('main'); });

  // ── Call controls ─────────────────────────────────────────────
  on('call-mute-btn',       () => toggleMute());
  on('call-cam-btn',        () => toggleCamera());
  on('call-switch-cam-btn', () => switchCamera());

  // ── Incoming call ─────────────────────────────────────────────
  on('accept-call-btn',  () => acceptCall());
  on('reject-call-btn',  () => rejectCall());

  // ── Contacts ─────────────────────────────────────────────────
  on('add-contact-btn',     () => showModal('add-contact'));
  on('confirm-add-contact', async () => {
    const id = val('add-contact-id');
    await handleAddContact(id);
    el('add-contact-id').value = '';
  });

  // ── Reports ──────────────────────────────────────────────────
  on('report-btn-profile', () => openReportModal(''));
  on('submit-report-btn',  () => handleSubmitReport());

  // ── Profile screen ────────────────────────────────────────────
  on('profile-avatar-edit', () => el('photo-file-input')?.click());
  on('photo-file-input', e => {
    const file = e.target.files?.[0];
    if (file) handleProfilePhotoChange(file);
    e.target.value = '';
  }, 'change');

  on('save-name-btn',     () => saveDisplayName());
  on('save-mobile-btn',   () => saveMobile());
  on('change-pass-btn',   () => handleChangePassword());
  on('resend-verify-btn', () => handleResendVerification());
  on('check-verify-btn',  () => checkEmailVerification());

  // ── Admin screen ──────────────────────────────────────────────
  on('open-admin-btn', () => showScreen('admin'));
  on('admin-tab-reports', () => showAdminTab('reports'));
  on('admin-tab-audit',   () => showAdminTab('audit'));
  on('admin-tab-search',  () => showAdminTab('search'));
  on('admin-search-btn',  () => {});  // handled inside admin.js

  // ── Privacy & Terms ("P&T") ───────────────────────────────────
  on('pt-btn', () => showModal('privacy-terms'));

  // ── Modal close buttons ───────────────────────────────────────
  document.querySelectorAll('.modal-close-btn').forEach(btn => {
    btn.addEventListener('click', hideModal);
  });

  // ── Image viewer ──────────────────────────────────────────────
  window._viewImage = url => {
    const viewer = el('image-viewer-modal');
    const img    = el('image-viewer-img');
    if (viewer && img) { img.src = url; showModal('image-viewer'); }
  };
}

// ─── Admin tab helper ──────────────────────────────────────────
function showAdminTab(tab) {
  ['reports','audit','search'].forEach(t => {
    const pane = el(`admin-${t}-pane`);
    if (pane) pane.style.display = t === tab ? 'block' : 'none';
    const btn = el(`admin-tab-${t}`);
    if (btn) btn.classList.toggle('active', t === tab);
  });
}

// ─── Helpers ──────────────────────────────────────────────────
function on(id, handler, event = 'click') {
  const node = el(id);
  if (node) node.addEventListener(event, handler);
}

function val(id) {
  return el(id)?.value?.trim() || '';
}
