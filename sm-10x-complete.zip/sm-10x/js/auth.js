/**
 * SM 10X — Authentication Module
 * Handles signup, login, logout, email verification, and the
 * critical auth→Firestore user-document→Member-ID creation flow.
 */

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  onAuthStateChanged,
  updateProfile
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';

import {
  doc, setDoc, getDoc, collection,
  query, where, getDocs, serverTimestamp,
  runTransaction, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

import { auth, db, APP } from './config.js';
import { showToast, showLoading, hideLoading } from './ui.js';

// ─── Member ID Generator ─────────────────────────────────────────────────────
/**
 * Generates a unique 8-digit numerical Member ID.
 * Uses the `memberIds` collection as a fast uniqueness index.
 * Retries up to 15 times before throwing.
 */
export async function generateMemberId() {
  const MAX_TRIES = 15;
  for (let i = 0; i < MAX_TRIES; i++) {
    const id = Math.floor(
      Math.random() * (APP.memberIdMax - APP.memberIdMin + 1) + APP.memberIdMin
    ).toString();

    const ref = doc(db, 'memberIds', id);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      // Reserve with 'pending' — will be replaced with the real UID
      await setDoc(ref, { uid: '__pending__', reservedAt: serverTimestamp() });
      return id;
    }
  }
  throw new Error('Unable to generate a unique Member ID. Please try again.');
}

// ─── Create Firestore user document ──────────────────────────────────────────
/**
 * Creates the users/{uid} document AND confirms the memberIds entry.
 * Called immediately after Firebase Auth account creation.
 */
export async function createUserDocument(uid, { displayName, email, mobile }) {
  const memberId = await generateMemberId();
  const userRef     = doc(db, 'users',     uid);
  const memberIdRef = doc(db, 'memberIds', memberId);

  const batch = writeBatch(db);

  batch.set(userRef, {
    uid,
    memberId,
    displayName: displayName || '',
    email,          // visible only to owner/admin via Firestore rules
    mobile:         mobile || null,
    photoURL:       null,
    isAdmin:        false,
    emailVerified:  false,
    createdAt:      serverTimestamp(),
    updatedAt:      serverTimestamp(),
    lastSeen:       serverTimestamp(),
    isOnline:       true
  });

  // Confirm the reservation with the real UID
  batch.set(memberIdRef, { uid, confirmedAt: serverTimestamp() });

  await batch.commit();
  return memberId;
}

// ─── Register ─────────────────────────────────────────────────────────────────
export async function register({ displayName, email, password, mobile }) {
  showLoading('Creating your account…');
  let userCredential;
  try {
    // 1. Create the Firebase Auth account
    userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const { user } = userCredential;

    // 2. Set display name on the auth profile
    await updateProfile(user, { displayName: displayName.trim() });

    // 3. Create Firestore document + Member ID (critical step)
    const memberId = await createUserDocument(user.uid, {
      displayName: displayName.trim(),
      email,
      mobile: mobile?.trim() || null
    });

    // 4. Send verification email (non-blocking)
    sendEmailVerification(user).catch(err =>
      console.warn('Verification email failed:', err)
    );

    hideLoading();
    showToast(`Welcome! Your Member ID is ${memberId}`, 'success', 6000);
    return { user, memberId };

  } catch (err) {
    hideLoading();

    // If Firestore step failed but Auth succeeded, clean up the Auth account
    if (userCredential?.user && err.code !== 'auth/email-already-in-use') {
      try { await userCredential.user.delete(); } catch (_) {}
    }

    throw err; // bubble up to UI handler
  }
}

// ─── Login ────────────────────────────────────────────────────────────────────
export async function login({ email, password }) {
  showLoading('Signing in…');
  try {
    const { user } = await signInWithEmailAndPassword(auth, email, password);
    hideLoading();
    return user;
  } catch (err) {
    hideLoading();
    throw err;
  }
}

// ─── Logout ───────────────────────────────────────────────────────────────────
export async function logout() {
  try {
    await signOut(auth);
  } catch (err) {
    console.error('Logout error:', err);
  }
}

// ─── Password Reset ───────────────────────────────────────────────────────────
export async function resetPassword(email) {
  showLoading('Sending reset email…');
  try {
    await sendPasswordResetEmail(auth, email);
    hideLoading();
    showToast('Password reset email sent. Check your inbox.', 'success');
  } catch (err) {
    hideLoading();
    throw err;
  }
}

// ─── Resend Verification Email ────────────────────────────────────────────────
export async function resendVerification() {
  const user = auth.currentUser;
  if (!user) throw new Error('Not signed in.');
  showLoading('Sending…');
  try {
    await sendEmailVerification(user);
    hideLoading();
    showToast('Verification email sent. Check your inbox.', 'success');
  } catch (err) {
    hideLoading();
    throw err;
  }
}

// ─── Reload auth user (to refresh emailVerified flag) ─────────────────────────
export async function reloadUser() {
  const user = auth.currentUser;
  if (user) await user.reload();
  return auth.currentUser;
}

// ─── Auth state listener ──────────────────────────────────────────────────────
export function onAuthChange(callback) {
  return onAuthStateChanged(auth, callback);
}

// ─── Error message mapper ──────────────────────────────────────────────────────
export function authErrorMsg(err) {
  const map = {
    'auth/email-already-in-use':    'That email is already registered.',
    'auth/invalid-email':           'Invalid email address.',
    'auth/weak-password':           'Password must be at least 6 characters.',
    'auth/user-not-found':          'No account found with that email.',
    'auth/wrong-password':          'Incorrect password.',
    'auth/invalid-credential':      'Incorrect email or password.',
    'auth/too-many-requests':       'Too many attempts. Please wait a moment.',
    'auth/network-request-failed':  'Network error. Check your connection.',
    'auth/user-disabled':           'This account has been disabled.'
  };
  return map[err.code] || err.message || 'An unexpected error occurred.';
}
