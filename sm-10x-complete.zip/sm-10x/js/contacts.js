/**
 * SM 10X — Contacts Module
 */

import { getContacts, listenContacts, addContact, removeContact, isContact, getUserByMemberId } from './db.js';
import { showToast, avatarHTML, escapeHTML, el, showModal, hideModal, showLoading, hideLoading } from './ui.js';
import { openChat, startChatByMemberId } from './messaging.js';

let _myUid         = null;
let _contactsUnsub = null;
let _contacts      = [];

export function initContacts(uid) {
  _myUid = uid;
  _contactsUnsub?.();
  _contactsUnsub = listenContacts(uid, contacts => {
    _contacts = contacts;
    renderContacts(contacts);
  });
}

export function destroyContacts() {
  _contactsUnsub?.();
  _myUid = null;
}

function renderContacts(contacts) {
  const container = el('contacts-list');
  if (!container) return;

  if (contacts.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <span class="empty-icon">👥</span>
      <p>No contacts yet.<br>Add a member using their 8-digit ID.</p>
    </div>`;
    return;
  }

  container.innerHTML = contacts.map(c => `
    <div class="contact-item" data-uid="${c.uid}">
      <div class="contact-avatar">${avatarHTML(c.displayName, c.photoURL, 46)}</div>
      <div class="contact-info">
        <span class="contact-name">${escapeHTML(c.displayName || 'Member')}</span>
        <span class="contact-id">ID: ${escapeHTML(c.memberId)}</span>
      </div>
      <div class="contact-actions">
        <button class="icon-btn contact-msg-btn" data-uid="${c.uid}" title="Message">💬</button>
        <button class="icon-btn contact-del-btn danger-icon" data-uid="${c.uid}" title="Remove">🗑️</button>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.contact-msg-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const c = contacts.find(x => x.uid === btn.dataset.uid);
      if (c) {
        // Open or create a conversation
        import('./db.js').then(({ getOrCreateConversation }) => {
          getOrCreateConversation(_myUid, c.uid, c).then(convId => {
            import('./messaging.js').then(({ openChat }) => openChat(convId, c.uid));
          });
        });
      }
    });
  });

  container.querySelectorAll('.contact-del-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      if (!confirm('Remove this contact?')) return;
      try {
        await removeContact(_myUid, btn.dataset.uid);
        showToast('Contact removed.', 'success');
      } catch (err) {
        showToast('Failed to remove contact.', 'error');
      }
    });
  });
}

export async function handleAddContact(memberId) {
  memberId = (memberId || '').trim();
  if (!/^\d{8}$/.test(memberId)) {
    showToast('Enter a valid 8-digit Member ID.', 'error');
    return;
  }

  const alreadyIn = _contacts.find(c => c.memberId === memberId);
  if (alreadyIn) { showToast('Already in your contacts.', 'info'); return; }

  showLoading('Finding member…');
  try {
    const user = await getUserByMemberId(memberId);
    if (!user) { hideLoading(); showToast('Member ID not found.', 'error'); return; }
    if (user.uid === _myUid) { hideLoading(); showToast('You cannot add yourself.', 'warning'); return; }

    await addContact(_myUid, user);
    hideLoading();
    showToast(`${user.displayName || 'Member'} added to contacts.`, 'success');
    hideModal();
  } catch (err) {
    hideLoading();
    showToast(err.message || 'Failed to add contact.', 'error');
  }
}

export function getContacts_() { return _contacts; }
