/**
 * SM 10X — Messaging Module
 * Conversation list, chat view, sending/receiving messages,
 * voice recording, image sharing, typing indicators.
 */

import { db } from './config.js';
import {
  listenConversations, listenMessages,
  getOrCreateConversation, sendMessage,
  markConversationRead, conversationId,
  getUserByMemberId, getUser
} from './db.js';
import {
  showScreen, showTab, showToast, showModal,
  escapeHTML, avatarHTML, formatTimestamp,
  formatTime, formatLastSeen, scrollBottom,
  el, setHTML, setText, updateBadge, showLoading, hideLoading
} from './ui.js';
import { uploadChatImage, uploadVoiceNote } from './cloudinary.js';
import { watchPresence, stopWatchingPresence } from './presence.js';
import { APP } from './config.js';

// ─── State ────────────────────────────────────────────────────
let _myUid        = null;
let _myProfile    = null;
let _convUnsubFn  = null;   // unsubscribe conversations listener
let _msgUnsubFn   = null;   // unsubscribe messages listener
let _presUnsubFn  = null;   // unsubscribe presence watcher
let _activeChatId = null;
let _activePartner = null;  // partner user object

// Voice recording
let _mediaRecorder = null;
let _audioChunks   = [];
let _recordingTimer = null;
let _recordingSeconds = 0;
let _isRecording   = false;

// Typing indicator
let _typingTimer = null;

// ─── Initialise for logged-in user ────────────────────────────
export function initMessaging(uid, profile) {
  _myUid     = uid;
  _myProfile = profile;
  _startConversationsListener();
}

export function destroyMessaging() {
  _convUnsubFn?.();
  _msgUnsubFn?.();
  _presUnsubFn?.();
  _myUid = _myProfile = _convUnsubFn = _msgUnsubFn = null;
}

// ─── Conversation list ────────────────────────────────────────
function _startConversationsListener() {
  if (!_myUid) return;
  _convUnsubFn?.();
  _convUnsubFn = listenConversations(_myUid, _renderConversationList);
}

function _renderConversationList(convos) {
  const container = el('chats-list');
  if (!container) return;

  // Total unread
  const totalUnread = convos.reduce((sum, c) => sum + (c.unreadCount?.[_myUid] || 0), 0);
  updateBadge('chats-badge', totalUnread);

  if (convos.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <span class="empty-icon">💬</span>
      <p>No conversations yet.<br>Search a Member ID to start chatting.</p>
    </div>`;
    return;
  }

  container.innerHTML = convos.map(c => {
    const partnerId   = c.participants.find(p => p !== _myUid);
    const partnerName = c.participantNames?.[partnerId] || 'Unknown';
    const photo       = c.participantPhotos?.[partnerId];
    const memberId    = c.participantMemberIds?.[partnerId] || '';
    const unread      = c.unreadCount?.[_myUid] || 0;
    const lastMsg     = c.lastMessage?.content || '';
    const ts          = c.lastMessageAt ? formatTimestamp(c.lastMessageAt) : '';

    return `
    <div class="chat-item" data-conv-id="${c.id}" data-partner-uid="${partnerId}">
      <div class="chat-avatar">${avatarHTML(partnerName, photo, 50)}</div>
      <div class="chat-info">
        <div class="chat-header-row">
          <span class="chat-name">${escapeHTML(partnerName)}</span>
          <span class="chat-time">${escapeHTML(ts)}</span>
        </div>
        <div class="chat-preview-row">
          <span class="chat-preview">${escapeHTML(lastMsg.substring(0,60))}</span>
          ${unread > 0
            ? `<span class="unread-badge">${unread > 99 ? '99+' : unread}</span>`
            : ''}
        </div>
        <div class="chat-memberid">ID: ${escapeHTML(memberId)}</div>
      </div>
    </div>`;
  }).join('');

  // Attach click listeners
  container.querySelectorAll('.chat-item').forEach(item => {
    item.addEventListener('click', () => {
      openChat(item.dataset.convId, item.dataset.partnerUid);
    });
  });
}

// ─── Open a chat by conversation ID ───────────────────────────
export async function openChat(convId, partnerUid) {
  try {
    _activeChatId = convId;

    // Load partner profile
    _activePartner = await getUser(partnerUid);
    if (!_activePartner) { showToast('Member not found.','error'); return; }

    // Render the chat header
    _renderChatHeader(_activePartner);

    // Subscribe to messages
    _msgUnsubFn?.();
    _msgUnsubFn = listenMessages(convId, msgs => {
      _renderMessages(msgs);
      // Mark read after render
      markConversationRead(convId, _myUid).catch(() => {});
    });

    // Watch partner presence
    _presUnsubFn?.();
    _presUnsubFn = watchPresence(partnerUid, ({ isOnline, lastSeen }) => {
      const statusEl = el('chat-partner-status');
      if (statusEl) {
        statusEl.textContent = isOnline
          ? 'Online'
          : `Last seen ${formatLastSeen(lastSeen)}`;
        statusEl.className = `partner-status ${isOnline ? 'online' : 'offline'}`;
      }
    });

    showScreen('chat');
  } catch (err) {
    console.error('openChat:', err);
    showToast('Failed to open chat.', 'error');
  }
}

/** Start a brand-new chat by Member ID */
export async function startChatByMemberId(memberId) {
  memberId = memberId.trim();
  if (!/^\d{8}$/.test(memberId)) {
    showToast('Please enter a valid 8-digit Member ID.', 'error');
    return;
  }
  if (memberId === _myProfile?.memberId) {
    showToast('You cannot message yourself.', 'warning');
    return;
  }

  showLoading('Finding member…');
  try {
    const partner = await getUserByMemberId(memberId);
    if (!partner) {
      hideLoading();
      showToast('Member ID not found.', 'error');
      return;
    }
    const convId = await getOrCreateConversation(_myUid, partner.uid, partner);
    hideLoading();
    openChat(convId, partner.uid);
  } catch (err) {
    hideLoading();
    showToast(err.message || 'Error starting chat.', 'error');
  }
}

// ─── Chat Header ──────────────────────────────────────────────
function _renderChatHeader(partner) {
  const nameEl   = el('chat-partner-name');
  const avatarEl = el('chat-partner-avatar');
  const idEl     = el('chat-partner-id');

  if (nameEl)   nameEl.textContent   = partner.displayName || 'Member';
  if (idEl)     idEl.textContent     = `ID: ${partner.memberId}`;
  if (avatarEl) avatarEl.innerHTML   = avatarHTML(partner.displayName, partner.photoURL, 38);
}

// ─── Message list render ──────────────────────────────────────
function _renderMessages(msgs) {
  const container = el('messages-container');
  if (!container) return;

  if (msgs.length === 0) {
    container.innerHTML = `<div class="empty-state" style="margin-top:80px;">
      <p>No messages yet. Say hello! 👋</p></div>`;
    return;
  }

  const html = msgs.map(msg => {
    if (msg.isDeleted) {
      return `<div class="msg-row ${msg.senderId === _myUid ? 'sent' : 'received'}">
                <div class="msg-bubble deleted-msg">🚫 Message deleted</div></div>`;
    }
    const isMine  = msg.senderId === _myUid;
    const rowCls  = isMine ? 'sent' : 'received';
    const ts      = msg.createdAt ? formatTime(msg.createdAt) : '';
    const readTick = isMine
      ? `<span class="msg-tick ${msg.readBy?.length > 1 ? 'read' : ''}">${msg.readBy?.length > 1 ? '✓✓' : '✓'}</span>`
      : '';

    let content = '';
    switch (msg.type) {
      case 'image':
        content = `<div class="msg-image" onclick="window._viewImage('${escapeHTML(msg.mediaUrl)}')">
                    <img src="${escapeHTML(msg.mediaUrl)}" alt="Image" loading="lazy">
                   </div>`;
        break;
      case 'voice':
        content = `<div class="msg-audio">
                    <audio controls src="${escapeHTML(msg.mediaUrl)}"></audio>
                   </div>`;
        break;
      default:
        content = `<p class="msg-text">${escapeHTML(msg.content)}</p>`;
    }

    return `
    <div class="msg-row ${rowCls}" data-msg-id="${msg.id}">
      <div class="msg-bubble ${rowCls}-bubble">
        ${content}
        <div class="msg-meta">
          <span class="msg-time">${ts}</span>${readTick}
        </div>
      </div>
    </div>`;
  }).join('');

  container.innerHTML = html;
  scrollBottom('messages-container');
}

// ─── Send text message ────────────────────────────────────────
export async function sendTextMessage() {
  if (!_activeChatId || !_activePartner) return;

  const input   = el('chat-input');
  const content = input?.value.trim();
  if (!content) return;

  if (content.length > APP.maxMsgLength) {
    showToast(`Message too long (max ${APP.maxMsgLength} chars).`, 'warning');
    return;
  }

  input.value = '';
  input.style.height = '';

  try {
    await sendMessage({
      convId:      _activeChatId,
      senderId:    _myUid,
      recipientId: _activePartner.uid,
      content,
      type:        'text'
    });
  } catch (err) {
    showToast('Message failed to send.', 'error');
    console.error(err);
  }
}

// ─── Send image ───────────────────────────────────────────────
export async function sendImageMessage(file) {
  if (!_activeChatId || !_activePartner) return;
  try {
    const { url, publicId } = await uploadChatImage(file);
    await sendMessage({
      convId: _activeChatId, senderId: _myUid, recipientId: _activePartner.uid,
      content: '[Image]', type: 'image',
      mediaUrl: url, mediaPublicId: publicId
    });
  } catch (err) {
    showToast(err.message || 'Image upload failed.', 'error');
  }
}

// ─── Voice recording ──────────────────────────────────────────
export async function startVoiceRecording() {
  if (_isRecording) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    _audioChunks  = [];
    _mediaRecorder = new MediaRecorder(stream);

    _mediaRecorder.ondataavailable = e => {
      if (e.data.size > 0) _audioChunks.push(e.data);
    };

    _mediaRecorder.onstop = async () => {
      stream.getTracks().forEach(t => t.stop());
      const blob = new Blob(_audioChunks, { type: 'audio/webm' });
      await _sendVoiceNote(blob, _recordingSeconds);
    };

    _mediaRecorder.start();
    _isRecording = true;
    _recordingSeconds = 0;

    const btn = el('voice-btn');
    if (btn) btn.classList.add('recording');

    _recordingTimer = setInterval(() => {
      _recordingSeconds++;
      const timerEl = el('recording-timer');
      if (timerEl) {
        const m = Math.floor(_recordingSeconds / 60).toString().padStart(2,'0');
        const s = (_recordingSeconds % 60).toString().padStart(2,'0');
        timerEl.textContent = `${m}:${s}`;
      }
      if (_recordingSeconds >= APP.maxVoiceSecs) stopVoiceRecording();
    }, 1000);

  } catch (err) {
    showToast('Microphone access denied.', 'error');
  }
}

export function stopVoiceRecording() {
  if (!_isRecording || !_mediaRecorder) return;
  _mediaRecorder.stop();
  _isRecording = false;
  clearInterval(_recordingTimer);

  const btn      = el('voice-btn');
  const timerEl  = el('recording-timer');
  if (btn)     btn.classList.remove('recording');
  if (timerEl) timerEl.textContent = '';
}

async function _sendVoiceNote(blob, duration) {
  if (!_activeChatId || !_activePartner) return;
  try {
    const { url, publicId } = await uploadVoiceNote(blob);
    await sendMessage({
      convId: _activeChatId, senderId: _myUid, recipientId: _activePartner.uid,
      content: '[Voice Note]', type: 'voice',
      mediaUrl: url, mediaPublicId: publicId, mediaDuration: duration
    });
  } catch (err) {
    showToast(err.message || 'Voice note upload failed.', 'error');
  }
}

// ─── Getters for active chat ──────────────────────────────────
export function getActiveChatId()     { return _activeChatId;    }
export function getActivePartner()    { return _activePartner;   }
export function getMyMessagingUid()   { return _myUid;           }
