/**
 * SM 10X — Configuration Module
 * Replace all YOUR_* placeholders with your real credentials.
 * This file initialises Firebase and exports the shared service
 * instances used by every other module.
 */

import { initializeApp }  from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import { getAuth }        from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
import { getFirestore }   from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

// ────────────────────────────────────────────────────────────
// FIREBASE — Console → Project Settings → Your apps → SDK
// ────────────────────────────────────────────────────────────
const firebaseConfig = {
  apiKey:            'YOUR_API_KEY',
  authDomain:        'YOUR_PROJECT_ID.firebaseapp.com',
  projectId:         'YOUR_PROJECT_ID',
  storageBucket:     'YOUR_PROJECT_ID.appspot.com',
  messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
  appId:             'YOUR_APP_ID'
};

const _app = initializeApp(firebaseConfig);
export const auth = getAuth(_app);
export const db   = getFirestore(_app);

// ────────────────────────────────────────────────────────────
// CLOUDINARY — cloudinary.com → Settings → Upload
// Create an *unsigned* upload preset and copy its name below.
// ────────────────────────────────────────────────────────────
export const CLOUDINARY = {
  cloudName:    'YOUR_CLOUD_NAME',
  uploadPreset: 'YOUR_UNSIGNED_PRESET',
  apiBase:      'https://api.cloudinary.com/v1_1'
};

// ────────────────────────────────────────────────────────────
// WEBRTC — Google STUN (free).  Add TURN credentials for
// cross-NAT reliability (Twilio / Xirsys are good choices).
// ────────────────────────────────────────────────────────────
export const WEBRTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302'  },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' }
    // { urls: 'turn:YOUR_HOST:3478', username: 'USER', credential: 'PASS' }
  ]
};

// ────────────────────────────────────────────────────────────
// APP CONSTANTS
// ────────────────────────────────────────────────────────────
export const APP = {
  name:             'SM 10X',
  version:          '1.0.0',
  memberIdMin:      10000000,
  memberIdMax:      99999999,
  maxMsgLength:     4000,
  maxFileBytes:     25 * 1024 * 1024,   // 25 MB
  maxVoiceSecs:     300,                 // 5 min
  allowedImages:    ['image/jpeg','image/png','image/gif','image/webp'],
  allowedAudio:     ['audio/webm','audio/ogg','audio/mp4','audio/wav','audio/aac'],
  typingTimeoutMs:  2500,
  presenceMs:       30_000,             // heartbeat every 30 s
  callTimeoutMs:    45_000,             // ring 45 s before marking missed
  adminUIDs:        []                   // add your admin UIDs here
};
