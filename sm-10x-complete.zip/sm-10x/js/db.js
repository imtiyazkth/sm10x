/**
 * SM 10X — Firestore Database Module
 * All Firestore reads/writes for every feature in the app.
 */

import {
  doc, collection, getDoc, getDocs, setDoc,
  updateDoc, addDoc, deleteDoc, query, where,
  orderBy, limit, onSnapshot, serverTimestamp,
  increment, arrayUnion, arrayRemove, writeBatch,
  Timestamp
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

import { db } from './config.js';

// ═══════════════════════════════════════════════════════════════════
//  USERS
// ═══════════════════════════════════════════════════════════════════

export async function getUser(uid) {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function updateUser(uid, data) {
  await updateDoc(doc(db, 'users', uid), {
    ...data,
    updatedAt: serverTimestamp()
  });
}

/**
 * Look up a user by their 8-digit Member ID.
 * Uses the memberIds index collection for O(1) lookup.
 */
export async function getUserByMemberId(memberId) {
  const idSnap = await getDoc(doc(db, 'memberIds', memberId));
  if (!idSnap.exists()) return null;
  const { uid } = idSnap.data();
  if (!uid || uid === '__pending__') return null;
  return getUser(uid);
}

/** Public-safe view of a user (no email, no mobile) */
export function publicProfile(user) {
  if (!user) return null;
  return {
    uid:         user.uid,
    memberId:    user.memberId,
    displayName: user.displayName,
    photoURL:    user.photoURL,
    isOnline:    user.isOnline,
    lastSeen:    user.lastSeen
  };
}

// ═══════════════════════════════════════════════════════════════════
//  CONVERSATIONS
// ═══════════════════════════════════════════════════════════════════

/** Stable conversation ID from two UIDs */
export function conversationId(uid1, uid2) {
  return [uid1, uid2].sort().join('_');
}

export async function getOrCreateConversation(myUid, theirUid, theirProfile) {
  const convId  = conversationId(myUid, theirUid);
  const convRef = doc(db, 'conversations', convId);
  const snap    = await getDoc(convRef);

  if (!snap.exists()) {
    const myProfile = await getUser(myUid);
    await setDoc(convRef, {
      participants: [myUid, theirUid],
      participantNames: {
        [myUid]:   myProfile?.displayName || '',
        [theirUid]: theirProfile?.displayName || ''
      },
      participantPhotos: {
        [myUid]:   myProfile?.photoURL || null,
        [theirUid]: theirProfile?.photoURL || null
      },
      participantMemberIds: {
        [myUid]:   myProfile?.memberId || '',
        [theirUid]: theirProfile?.memberId || ''
      },
      lastMessage:   null,
      lastMessageAt: null,
      unreadCount:   { [myUid]: 0, [theirUid]: 0 },
      createdAt:     serverTimestamp()
    });
  }
  return convId;
}

export function listenConversations(uid, callback) {
  const q = query(
    collection(db, 'conversations'),
    where('participants', 'array-contains', uid),
    orderBy('lastMessageAt', 'desc'),
    limit(50)
  );
  return onSnapshot(q, snap => {
    const convos = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    callback(convos);
  });
}

// ═══════════════════════════════════════════════════════════════════
//  MESSAGES
// ═══════════════════════════════════════════════════════════════════

export function listenMessages(convId, callback) {
  const q = query(
    collection(db, 'conversations', convId, 'messages'),
    orderBy('createdAt', 'asc'),
    limit(200)
  );
  return onSnapshot(q, snap => {
    const msgs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    callback(msgs);
  });
}

export async function sendMessage({
  convId, senderId, recipientId,
  content, type = 'text',
  mediaUrl = null, mediaPublicId = null, mediaDuration = null
}) {
  const msgRef  = doc(collection(db, 'conversations', convId, 'messages'));
  const convRef = doc(db, 'conversations', convId);

  const message = {
    id:             msgRef.id,
    senderId,
    content:        content || '',
    type,
    mediaUrl,
    mediaPublicId,
    mediaDuration,
    readBy:         [senderId],
    isDeleted:      false,
    createdAt:      serverTimestamp()
  };

  const batch = writeBatch(db);
  batch.set(msgRef, message);
  batch.update(convRef, {
    lastMessage: {
      content: type === 'text' ? content : `[${type}]`,
      senderId,
      type
    },
    lastMessageAt:                      serverTimestamp(),
    [`unreadCount.${recipientId}`]:     increment(1)
  });

  await batch.commit();
  return message;
}

export async function markConversationRead(convId, uid) {
  const convRef = doc(db, 'conversations', convId);
  await updateDoc(convRef, { [`unreadCount.${uid}`]: 0 });

  // Mark all unread messages as read
  const q = query(
    collection(db, 'conversations', convId, 'messages'),
    where('readBy', 'not-in', [[uid]])
  );
  const snaps = await getDocs(q);
  const batch = writeBatch(db);
  snaps.docs.forEach(d => batch.update(d.ref, { readBy: arrayUnion(uid) }));
  await batch.commit();
}

export async function deleteMessage(convId, msgId) {
  const ref = doc(db, 'conversations', convId, 'messages', msgId);
  await updateDoc(ref, { isDeleted: true, content: '', mediaUrl: null });
}

// ═══════════════════════════════════════════════════════════════════
//  CONTACTS
// ═══════════════════════════════════════════════════════════════════

export async function getContacts(uid) {
  const snap = await getDocs(collection(db, 'users', uid, 'contacts'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export function listenContacts(uid, callback) {
  return onSnapshot(collection(db, 'users', uid, 'contacts'), snap => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  });
}

export async function addContact(myUid, contactUser) {
  const ref = doc(db, 'users', myUid, 'contacts', contactUser.uid);
  const existing = await getDoc(ref);
  if (existing.exists()) throw new Error('Already in contacts.');
  await setDoc(ref, {
    uid:         contactUser.uid,
    memberId:    contactUser.memberId,
    displayName: contactUser.displayName || '',
    photoURL:    contactUser.photoURL || null,
    addedAt:     serverTimestamp()
  });
}

export async function removeContact(myUid, contactUid) {
  await deleteDoc(doc(db, 'users', myUid, 'contacts', contactUid));
}

export async function isContact(myUid, contactUid) {
  const snap = await getDoc(doc(db, 'users', myUid, 'contacts', contactUid));
  return snap.exists();
}

// ═══════════════════════════════════════════════════════════════════
//  REPORTS
// ═══════════════════════════════════════════════════════════════════

export async function submitReport({
  reporterUid, targetMemberId, targetUid,
  category, description
}) {
  await addDoc(collection(db, 'reports'), {
    reporterUid,   // visible to admins
    targetMemberId,
    targetUid,
    category,
    description:   description || '',
    status:        'pending',  // pending | reviewed | resolved | dismissed
    adminNotes:    '',
    reviewedBy:    null,
    createdAt:     serverTimestamp(),
    updatedAt:     serverTimestamp()
  });
}

export function listenReports(callback) {
  const q = query(
    collection(db, 'reports'),
    orderBy('createdAt', 'desc'),
    limit(100)
  );
  return onSnapshot(q, snap => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  });
}

export async function updateReport(reportId, adminUid, { status, adminNotes }) {
  await updateDoc(doc(db, 'reports', reportId), {
    status, adminNotes,
    reviewedBy: adminUid,
    updatedAt:  serverTimestamp()
  });
}

// ═══════════════════════════════════════════════════════════════════
//  NOTIFICATIONS (in-app)
// ═══════════════════════════════════════════════════════════════════

export function listenNotifications(uid, callback) {
  const q = query(
    collection(db, 'users', uid, 'notifications'),
    orderBy('createdAt', 'desc'),
    limit(30)
  );
  return onSnapshot(q, snap => {
    callback(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  });
}

export async function addNotification(targetUid, { type, title, body, data }) {
  await addDoc(collection(db, 'users', targetUid, 'notifications'), {
    type, title, body, data: data || {},
    isRead: false,
    createdAt: serverTimestamp()
  });
}

export async function markNotificationRead(uid, notifId) {
  await updateDoc(doc(db, 'users', uid, 'notifications', notifId), { isRead: true });
}

// ═══════════════════════════════════════════════════════════════════
//  CALL LOGS
// ═══════════════════════════════════════════════════════════════════

export async function createCallLog({
  callId, callerId, receiverId,
  callerMemberId, receiverMemberId, type
}) {
  await setDoc(doc(db, 'callLogs', callId), {
    callId,
    callerId, receiverId,
    callerMemberId, receiverMemberId,
    type,    // 'audio' | 'video'
    status:  'ringing',
    offer:   null, answer: null,
    startedAt: null, endedAt: null,
    duration:  null, endedBy: null,
    createdAt: serverTimestamp()
  });
}

export async function updateCallLog(callId, updates) {
  await updateDoc(doc(db, 'callLogs', callId), {
    ...updates,
    updatedAt: serverTimestamp()
  });
}

export function listenCallLogs(uid, callback) {
  const q = query(
    collection(db, 'callLogs'),
    where('participants', 'array-contains', uid),
    orderBy('createdAt', 'desc'),
    limit(50)
  );
  return onSnapshot(q, snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}

// ═══════════════════════════════════════════════════════════════════
//  ADMIN AUDIT LOGS
// ═══════════════════════════════════════════════════════════════════

export async function logAdminAction({ adminUid, action, targetId, targetType, reason }) {
  await addDoc(collection(db, 'adminAuditLogs'), {
    adminUid, action,
    targetId, targetType,
    reason:    reason || '',
    createdAt: serverTimestamp()
  });
}

export function listenAuditLogs(callback) {
  const q = query(
    collection(db, 'adminAuditLogs'),
    orderBy('createdAt', 'desc'),
    limit(200)
  );
  return onSnapshot(q, snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
}

// ═══════════════════════════════════════════════════════════════════
//  SIGNALING (WebRTC)
// ═══════════════════════════════════════════════════════════════════

export async function createSignalDoc(callId, data) {
  await setDoc(doc(db, 'calls', callId), {
    ...data,
    createdAt: serverTimestamp()
  });
}

export async function updateSignalDoc(callId, data) {
  await updateDoc(doc(db, 'calls', callId), data);
}

export async function getSignalDoc(callId) {
  const snap = await getDoc(doc(db, 'calls', callId));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export function listenSignalDoc(callId, callback) {
  return onSnapshot(doc(db, 'calls', callId), snap => {
    if (snap.exists()) callback({ id: snap.id, ...snap.data() });
  });
}

export async function addIceCandidate(callId, side, candidate) {
  // side: 'offerCandidates' | 'answerCandidates'
  await addDoc(collection(db, 'calls', callId, side), { candidate });
}

export function listenIceCandidates(callId, side, callback) {
  return onSnapshot(
    collection(db, 'calls', callId, side),
    snap => snap.docChanges().forEach(change => {
      if (change.type === 'added') callback(change.doc.data().candidate);
    })
  );
}
