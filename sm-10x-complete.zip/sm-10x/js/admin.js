/**
 * SM 10X — Admin Panel Module
 * Only rendered/accessible when the signed-in UID is in APP.adminUIDs.
 * Every admin action is logged to adminAuditLogs.
 */

import { APP } from './config.js';
import {
  listenReports, updateReport, listenAuditLogs,
  getUser, getUserByMemberId, updateUser, logAdminAction
} from './db.js';
import {
  showToast, escapeHTML, el, setHTML, setText,
  formatTimestamp, showLoading, hideLoading, showModal, hideModal
} from './ui.js';

let _adminUid     = null;
let _reportUnsub  = null;
let _auditUnsub   = null;
let _currentReport = null;

export function isAdmin(uid) {
  return APP.adminUIDs.includes(uid);
}

export function initAdmin(uid) {
  if (!isAdmin(uid)) return;
  _adminUid = uid;
  _loadReports();
  _loadAuditLogs();
  _setupAdminSearch();
}

export function destroyAdmin() {
  _reportUnsub?.();
  _auditUnsub?.();
  _adminUid = null;
}

// ─── Reports ──────────────────────────────────────────────────
function _loadReports() {
  _reportUnsub?.();
  _reportUnsub = listenReports(reports => {
    const container = el('admin-reports-list');
    if (!container) return;

    const pending = reports.filter(r => r.status === 'pending');
    const badge   = el('admin-reports-badge');
    if (badge) badge.textContent = pending.length || '';

    if (reports.length === 0) {
      container.innerHTML = `<p class="empty-state-text">No reports yet.</p>`;
      return;
    }

    container.innerHTML = reports.map(r => `
      <div class="admin-report-card ${r.status}" data-id="${r.id}">
        <div class="report-header">
          <span class="report-status-tag status-${r.status}">${r.status.toUpperCase()}</span>
          <span class="report-cat">${escapeHTML(r.category)}</span>
          <span class="report-time">${r.createdAt ? formatTimestamp(r.createdAt) : ''}</span>
        </div>
        <div class="report-body">
          <p><strong>Target Member ID:</strong> ${escapeHTML(r.targetMemberId)}</p>
          <p><strong>Description:</strong> ${escapeHTML(r.description || '—')}</p>
          ${r.adminNotes ? `<p><strong>Admin Notes:</strong> ${escapeHTML(r.adminNotes)}</p>` : ''}
          ${r.reviewedBy  ? `<p><strong>Reviewed by:</strong> ${escapeHTML(r.reviewedBy)}</p>` : ''}
        </div>
        <div class="report-actions">
          <button class="btn btn-sm btn-warning" data-report-id="${r.id}" data-action="review">
            Mark Reviewed
          </button>
          <button class="btn btn-sm btn-success" data-report-id="${r.id}" data-action="resolve">
            Resolve
          </button>
          <button class="btn btn-sm btn-secondary" data-report-id="${r.id}" data-action="dismiss">
            Dismiss
          </button>
        </div>
      </div>
    `).join('');

    // Attach action buttons
    container.querySelectorAll('[data-report-id]').forEach(btn => {
      btn.addEventListener('click', () => _handleReportAction(
        btn.dataset.reportId, btn.dataset.action, reports
      ));
    });
  });
}

async function _handleReportAction(reportId, action, reports) {
  const notes = action === 'review'
    ? prompt('Admin notes (optional):') ?? ''
    : '';

  const statusMap = { review: 'reviewed', resolve: 'resolved', dismiss: 'dismissed' };
  const newStatus = statusMap[action];
  if (!newStatus) return;

  showLoading('Updating report…');
  try {
    await updateReport(reportId, _adminUid, { status: newStatus, adminNotes: notes });
    await logAdminAction({
      adminUid:   _adminUid,
      action:     `report_${newStatus}`,
      targetId:   reportId,
      targetType: 'report',
      reason:     notes
    });
    hideLoading();
    showToast(`Report marked as ${newStatus}.`, 'success');
  } catch (err) {
    hideLoading();
    showToast('Failed to update report.', 'error');
  }
}

// ─── Audit Logs ───────────────────────────────────────────────
function _loadAuditLogs() {
  _auditUnsub?.();
  _auditUnsub = listenAuditLogs(logs => {
    const container = el('admin-audit-list');
    if (!container) return;

    if (logs.length === 0) {
      container.innerHTML = `<p class="empty-state-text">No audit logs yet.</p>`;
      return;
    }

    container.innerHTML = logs.map(log => `
      <div class="audit-log-item">
        <span class="audit-time">${log.createdAt ? formatTimestamp(log.createdAt) : ''}</span>
        <span class="audit-admin">Admin: ${escapeHTML(log.adminUid)}</span>
        <span class="audit-action">${escapeHTML(log.action)}</span>
        <span class="audit-target">Target: ${escapeHTML(log.targetId)}</span>
        ${log.reason ? `<span class="audit-reason">${escapeHTML(log.reason)}</span>` : ''}
      </div>
    `).join('');
  });
}

// ─── Admin User Search ────────────────────────────────────────
function _setupAdminSearch() {
  const btn = el('admin-search-btn');
  if (btn) btn.addEventListener('click', _handleAdminUserSearch);
}

async function _handleAdminUserSearch() {
  const input    = el('admin-search-input');
  const memberId = input?.value.trim();
  if (!memberId) return;

  showLoading('Searching…');
  try {
    const user = await getUserByMemberId(memberId);
    hideLoading();
    if (!user) { showToast('Member not found.', 'error'); return; }
    _renderAdminUserDetail(user);
  } catch (err) {
    hideLoading();
    showToast('Search failed.', 'error');
  }
}

function _renderAdminUserDetail(user) {
  const container = el('admin-user-detail');
  if (!container) return;

  container.style.display = 'block';
  container.innerHTML = `
    <div class="admin-user-card">
      <h3>Member Details</h3>
      <table class="admin-detail-table">
        <tr><td>UID</td><td>${escapeHTML(user.uid)}</td></tr>
        <tr><td>Member ID</td><td>${escapeHTML(user.memberId)}</td></tr>
        <tr><td>Display Name</td><td>${escapeHTML(user.displayName || '—')}</td></tr>
        <tr><td>Email</td><td>${escapeHTML(user.email || '—')}</td></tr>
        <tr><td>Mobile</td><td>${escapeHTML(user.mobile || '—')}</td></tr>
        <tr><td>Email Verified</td><td>${user.emailVerified ? '✅ Yes' : '❌ No'}</td></tr>
        <tr><td>Account Created</td><td>${user.createdAt ? formatTimestamp(user.createdAt) : '—'}</td></tr>
        <tr><td>Last Seen</td><td>${user.lastSeen ? formatTimestamp(user.lastSeen) : '—'}</td></tr>
        <tr><td>Online Now</td><td>${user.isOnline ? '🟢 Yes' : '⚪ No'}</td></tr>
      </table>
      <div class="admin-mod-actions">
        <button class="btn btn-sm btn-warning" id="admin-suspend-btn">Suspend Account</button>
        <button class="btn btn-sm btn-secondary" id="admin-note-btn">Add Note</button>
      </div>
    </div>
  `;

  el('admin-suspend-btn')?.addEventListener('click', async () => {
    if (!confirm(`Suspend ${user.displayName || user.memberId}?`)) return;
    const reason = prompt('Reason for suspension:') || 'Admin action';
    showLoading('Suspending…');
    try {
      await updateUser(user.uid, { suspended: true, suspendedReason: reason });
      await logAdminAction({
        adminUid: _adminUid, action: 'user_suspended',
        targetId: user.uid, targetType: 'user', reason
      });
      hideLoading();
      showToast('Account suspended.', 'success');
    } catch (err) {
      hideLoading();
      showToast('Failed to suspend.', 'error');
    }
  });

  el('admin-note-btn')?.addEventListener('click', async () => {
    const note = prompt('Add an admin note for this user:');
    if (!note) return;
    showLoading('Saving…');
    try {
      await updateUser(user.uid, { adminNote: note });
      await logAdminAction({
        adminUid: _adminUid, action: 'user_note_added',
        targetId: user.uid, targetType: 'user', reason: note
      });
      hideLoading();
      showToast('Note saved.', 'success');
    } catch (err) {
      hideLoading();
      showToast('Failed to save note.', 'error');
    }
  });
}
