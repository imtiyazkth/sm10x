/**
 * SM 10X — Cloudinary Media Module
 * All media uploads go through Cloudinary.
 * Firebase Storage is NOT used.
 */

import { CLOUDINARY, APP } from './config.js';
import { showToast, showLoading, hideLoading } from './ui.js';

// ─── Core uploader ────────────────────────────────────────────
async function uploadToCloudinary(file, folder, resourceType = 'auto') {
  if (!CLOUDINARY.cloudName || CLOUDINARY.cloudName === 'YOUR_CLOUD_NAME') {
    throw new Error('Cloudinary is not configured. See js/config.js.');
  }

  const form = new FormData();
  form.append('file',           file);
  form.append('upload_preset',  CLOUDINARY.uploadPreset);
  form.append('folder',         `sm10x/${folder}`);

  const url = `${CLOUDINARY.apiBase}/${CLOUDINARY.cloudName}/${resourceType}/upload`;
  const res  = await fetch(url, { method: 'POST', body: form });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Upload failed.');
  }
  return res.json();
}

// ─── Profile Photo ────────────────────────────────────────────
export async function uploadProfilePhoto(file, uid) {
  if (!APP.allowedImages.includes(file.type)) {
    throw new Error('Please choose a JPG, PNG, GIF, or WebP image.');
  }
  if (file.size > APP.maxFileBytes) {
    throw new Error('File is too large (max 25 MB).');
  }
  showLoading('Uploading photo…');
  try {
    const data = await uploadToCloudinary(
      file,
      `avatars/${uid}`,
      'image'
    );
    hideLoading();
    // Return the auto-quality optimised URL
    return {
      url:      data.secure_url.replace('/upload/', '/upload/q_auto,f_auto,w_400,h_400,c_fill/'),
      publicId: data.public_id
    };
  } catch (err) {
    hideLoading();
    throw err;
  }
}

// ─── Chat Image ───────────────────────────────────────────────
export async function uploadChatImage(file) {
  if (!APP.allowedImages.includes(file.type)) {
    throw new Error('Please choose a JPG, PNG, GIF, or WebP image.');
  }
  if (file.size > APP.maxFileBytes) {
    throw new Error('File is too large (max 25 MB).');
  }
  showLoading('Uploading image…');
  try {
    const data = await uploadToCloudinary(file, 'chat-images', 'image');
    hideLoading();
    return {
      url:       data.secure_url.replace('/upload/', '/upload/q_auto,f_auto/'),
      thumbnail: data.secure_url.replace('/upload/', '/upload/q_auto,f_auto,w_300,h_300,c_limit/'),
      publicId:  data.public_id,
      width:     data.width,
      height:    data.height
    };
  } catch (err) {
    hideLoading();
    throw err;
  }
}

// ─── Voice Note ───────────────────────────────────────────────
export async function uploadVoiceNote(audioBlob) {
  if (audioBlob.size > APP.maxFileBytes) {
    throw new Error('Voice note is too large (max 25 MB).');
  }
  // Cloudinary accepts raw audio blobs
  const file = new File([audioBlob], 'voice-note.webm', { type: audioBlob.type });
  showLoading('Uploading voice note…');
  try {
    const data = await uploadToCloudinary(file, 'voice-notes', 'raw');
    hideLoading();
    return {
      url:      data.secure_url,
      publicId: data.public_id
    };
  } catch (err) {
    hideLoading();
    throw err;
  }
}

// ─── Validate file before picking ─────────────────────────────
export function validateImageFile(file) {
  if (!APP.allowedImages.includes(file.type))
    return 'Unsupported file type.';
  if (file.size > APP.maxFileBytes)
    return 'File too large (max 25 MB).';
  return null;
}

// ─── Create object URL for preview ────────────────────────────
export function previewURL(file) {
  return URL.createObjectURL(file);
}

export function revokePreview(url) {
  URL.revokeObjectURL(url);
}
