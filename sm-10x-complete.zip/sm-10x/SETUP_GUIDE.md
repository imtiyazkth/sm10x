# SM 10X — Complete Setup, Deployment & Debugging Guide
# Written for Android-only workflow (no PC required)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

---

## 1. PROJECT OVERVIEW

SM 10X is a private member-to-member messaging web app.
- Frontend : Vanilla JS (ES Modules) — no build step needed
- Auth     : Firebase Authentication
- Database : Cloud Firestore
- Media    : Cloudinary (NOT Firebase Storage)
- Calls    : Browser WebRTC + Firestore signaling
- Hosting  : Firebase Hosting (deployed via GitHub Actions)

---

## 2. FILE STRUCTURE

```
sm-10x/
├── index.html                   ← Single-page app shell
├── firebase.json                ← Hosting + Firestore config
├── firestore.rules              ← Security rules
├── firestore.indexes.json       ← Composite index definitions
├── css/
│   └── style.css                ← All styles
├── js/
│   ├── config.js                ← Firebase, Cloudinary, WebRTC, constants
│   ├── app.js                   ← Entry point, all event listeners
│   ├── auth.js                  ← Auth flows + Member ID generation
│   ├── db.js                    ← All Firestore read/write operations
│   ├── messaging.js             ← Chat + voice notes + image sending
│   ├── contacts.js              ← Contact list management
│   ├── calls.js                 ← WebRTC audio/video calling
│   ├── presence.js              ← Online/offline/last-seen tracking
│   ├── cloudinary.js            ← Cloudinary upload helpers
│   ├── reports.js               ← Member reporting system
│   ├── admin.js                 ← Admin panel (reports, audit, user search)
│   ├── profile.js               ← Profile view/edit
│   └── ui.js                    ← DOM helpers, toasts, modals, time format
└── .github/
    └── workflows/
        └── firebase-deploy.yml  ← Auto-deploy on push to main
```

---

## 3. FIRESTORE SCHEMA

### Collection: `users`
```
users/{uid}
  uid            : string   (Firebase Auth UID)
  memberId       : string   (unique 8-digit number, e.g. "47382910")
  displayName    : string
  email          : string   ← PRIVATE (owner + admin only)
  mobile         : string|null ← OPTIONAL, PRIVATE
  photoURL       : string|null
  isAdmin        : boolean  (set by Admin SDK custom claim only)
  emailVerified  : boolean  (synced from Auth token)
  isOnline       : boolean
  lastSeen       : timestamp
  createdAt      : timestamp
  updatedAt      : timestamp
  suspended      : boolean  (admin use)
  adminNote      : string   (admin use)
```

### Collection: `memberIds` (index)
```
memberIds/{memberId}
  uid            : string
  confirmedAt    : timestamp
```

### Collection: `conversations`
```
conversations/{uid1_uid2}   ← sorted UIDs joined by _
  participants          : string[]
  participantNames      : map {uid: name}
  participantPhotos     : map {uid: photoURL}
  participantMemberIds  : map {uid: memberId}
  lastMessage           : map {content, senderId, type}
  lastMessageAt         : timestamp
  unreadCount           : map {uid: number}
  createdAt             : timestamp

  /messages/{msgId}
    id             : string
    senderId       : string
    content        : string
    type           : "text"|"image"|"voice"
    mediaUrl       : string|null  ← Cloudinary URL
    mediaPublicId  : string|null
    mediaDuration  : number|null  (seconds for voice)
    readBy         : string[]     (UIDs)
    isDeleted      : boolean
    createdAt      : timestamp
```

### Collection: `contacts`
```
users/{uid}/contacts/{contactUid}
  uid          : string
  memberId     : string
  displayName  : string
  photoURL     : string|null
  addedAt      : timestamp
```

### Collection: `calls` (WebRTC signaling)
```
calls/{callId}
  callId           : string
  callerId         : string
  receiverId       : string
  callerName       : string
  callerMemberId   : string
  receiverMemberId : string
  type             : "audio"|"video"
  status           : "ringing"|"active"|"rejected"|"ended"
  offer            : {sdp, type}
  answer           : {sdp, type}
  createdAt        : timestamp

  /offerCandidates/{id}   { candidate }
  /answerCandidates/{id}  { candidate }
```

### Collection: `reports`
```
reports/{reportId}
  reporterUid    : string  ← PRIVATE, admin-only
  targetMemberId : string
  targetUid      : string
  category       : string
  description    : string
  status         : "pending"|"reviewed"|"resolved"|"dismissed"
  adminNotes     : string
  reviewedBy     : string|null
  createdAt      : timestamp
  updatedAt      : timestamp
```

### Collection: `callLogs`
```
callLogs/{callId}
  callerId, receiverId, callerMemberId, receiverMemberId
  type, status, duration, endedBy
  startedAt, endedAt, createdAt
```

### Collection: `adminAuditLogs`
```
adminAuditLogs/{logId}
  adminUid   : string
  action     : string
  targetId   : string
  targetType : string
  reason     : string
  createdAt  : timestamp
```

### Subcollection: `notifications`
```
users/{uid}/notifications/{notifId}
  type, title, body, data, isRead, createdAt
```

---

## 4. STEP-BY-STEP SETUP (ANDROID PHONE)

### Step A — Create a Firebase Project

1. Open Chrome on your Android phone.
2. Go to: https://console.firebase.google.com
3. Tap "Add project" → Name it "SM 10X" → Continue → Disable Analytics (optional) → Create.
4. Once created, tap the web icon `</>` to add a Web App.
5. Register it as "sm10x-web". Firebase will show you a `firebaseConfig` object.
6. COPY all the values. You will paste them into `js/config.js`.

### Step B — Enable Firebase Authentication

1. In the Firebase Console → Build → Authentication → Get Started.
2. Enable "Email/Password" provider → Save.

### Step C — Create Firestore Database

1. Firebase Console → Build → Firestore Database → Create Database.
2. Choose "Start in production mode" (our rules handle permissions).
3. Pick a server region close to your users → Enable.

### Step D — Set up Cloudinary

1. Go to: https://cloudinary.com → Sign Up (free tier is fine).
2. After login, go to Settings → Upload Presets → Add upload preset.
3. Set Signing Mode to "Unsigned".
4. Save the preset name.
5. Your Cloud Name is shown on the dashboard homepage.

### Step E — Fill in your credentials

Open `js/config.js` in any text editor (e.g. Acode app on Android) and
replace every `YOUR_*` placeholder:

```js
const firebaseConfig = {
  apiKey:            'AIzaSy...',         // from Firebase Console
  authDomain:        'sm10x-abc.firebaseapp.com',
  projectId:         'sm10x-abc',
  storageBucket:     'sm10x-abc.appspot.com',
  messagingSenderId: '123456789',
  appId:             '1:123:web:abc123'
};

export const CLOUDINARY = {
  cloudName:    'your-cloud-name',
  uploadPreset: 'sm10x_unsigned',
  ...
};
```

Also update `firebase.json` → replace `YOUR_PROJECT_ID` with your real project ID.
Update `.github/workflows/firebase-deploy.yml` → replace `YOUR_PROJECT_ID`.

### Step F — Add Admin UID(s)

To make yourself an admin:
1. Register in the app normally to get your UID.
2. In Firebase Console → Firestore → `users` collection → find your document.
3. Copy your UID.
4. In `js/config.js` → `APP.adminUIDs` array → paste your UID:
   ```js
   adminUIDs: ['your-uid-here']
   ```
5. Optionally set the Firebase custom claim via Firebase Admin SDK (Node.js script):
   ```js
   admin.auth().setCustomUserClaims('your-uid', { admin: true });
   ```

### Step G — Deploy Firestore Rules and Indexes

Option 1 (Firebase Console — easiest on Android):
1. Firebase Console → Firestore → Rules tab.
2. Delete all existing content.
3. Copy the entire content of `firestore.rules` and paste it.
4. Click Publish.
5. Firebase Console → Firestore → Indexes tab.
6. Composite indexes listed in `firestore.indexes.json` can be created manually,
   OR they will be auto-prompted the first time a query runs.

Option 2 (Firebase CLI — if you have Termux on Android):
```sh
pkg install nodejs
npm install -g firebase-tools
firebase login
firebase deploy --only firestore:rules,firestore:indexes
```

---

## 5. GITHUB SETUP AND DEPLOYMENT

### Step 1 — Create a GitHub repository

1. Open https://github.com on your Android phone.
2. Create a new repository named `sm-10x` (public or private).
3. DO NOT initialise with README.

### Step 2 — Push code to GitHub

Use the GitHub mobile app or a Git client (GitJourney / MGit on Android):

```
git init
git add .
git commit -m "Initial SM 10X commit"
git remote add origin https://github.com/YOUR_USERNAME/sm-10x.git
git push -u origin main
```

Or use GitHub's web file uploader to upload each file.

### Step 3 — Add Firebase Service Account secret

1. Firebase Console → Project Settings → Service Accounts.
2. Click "Generate new private key" → Download JSON.
3. GitHub → your repo → Settings → Secrets and variables → Actions → New secret.
4. Name: `FIREBASE_SERVICE_ACCOUNT`
5. Value: paste the entire JSON content.

### Step 4 — Trigger auto-deploy

Push any change to `main` branch.
GitHub Actions will automatically run `.github/workflows/firebase-deploy.yml`
and deploy to Firebase Hosting.

### Step 5 — Get your live URL

After deploy succeeds, your site is live at:
```
https://YOUR_PROJECT_ID.web.app
```

---

## 6. DEBUGGING CHECKLIST: Auth → Firestore → Member ID

If a user registers but has no Member ID or profile:

```
✅ Check 1: Firebase Auth account created?
   → Firebase Console → Authentication → Users
   → If the user appears there, auth succeeded.

✅ Check 2: Firestore `users/{uid}` document created?
   → Firestore → users collection → find the uid
   → If missing: check Firestore Rules (allow create for new users)
   → Check that `isAdmin == false` in the request data matches the rule

✅ Check 3: memberIds index document created?
   → Firestore → memberIds collection → look for an 8-digit doc
   → If missing: the writeBatch in createUserDocument() failed
   → Check browser console for errors

✅ Check 4: Firestore Rules blocking creation?
   → Temporarily set: allow create: if true;  in users/{uid}
   → Try registering again → if it works, rules are the issue
   → Fix the rule then re-enable production rules

✅ Check 5: Network error during registration?
   → Open Chrome DevTools (chrome://inspect on desktop, or Eruda on mobile)
   → Check Network tab for failed Firestore requests

✅ Check 6: Race condition — Auth created but Firestore failed?
   → The fallback in app.js onAuthChange() detects a missing Firestore
     document and calls createUserDocument() again automatically.
   → Check the console for: "Setting up your profile…" toast

✅ Check 7: Member ID collision (extremely rare)?
   → The generator retries 15 times before throwing
   → Check console for: "Unable to generate a unique Member ID"

✅ Check 8: Email verification not arriving?
   → Check spam folder
   → Firebase Console → Authentication → Users → click the user → resend
   → Or use the "Resend" button in the app's profile tab

✅ Check 9: Verified user still blocked from messaging?
   → The app checks request.auth.token.email_verified in Firestore rules
   → The user must sign OUT and sign IN again after verifying email
     so the Auth token refreshes with the new claim
   → OR call user.reload() then getIdToken(true) to force a token refresh
```

---

## 7. MOBILE NUMBER — IMPLEMENTATION NOTES

- The `mobile` field is completely optional.
- If the user leaves the field empty during registration, `mobile` is stored as `null`.
- No warning, badge, restriction, or notification is shown for missing mobile.
- The field is stored in `users/{uid}` under the `mobile` key.
- Firestore Rules restrict `mobile` visibility: only the owner UID and admins can read
  the full `users/{uid}` document (which contains `mobile` and `email`).
- Other users only receive public profile data (uid, memberId, displayName, photoURL).
- The admin panel displays `mobile` for support/moderation purposes.

---

## 8. CLOUDINARY MEDIA — IMPLEMENTATION NOTES

- Firebase Storage is NOT used anywhere in this project.
- All media (profile photos, chat images, voice notes) is uploaded to Cloudinary.
- The upload uses an *unsigned* upload preset (no secret key in the browser).
- After upload, only the Cloudinary `secure_url` and `public_id` are stored in Firestore.
- Images are auto-optimised via Cloudinary transformation URLs (q_auto, f_auto).
- To delete a Cloudinary asset, use the Admin API (server-side only) with your API secret.
- Voice notes are uploaded as raw binary (audio/webm).
- Maximum file size: 25 MB (configurable in APP.maxFileBytes in config.js).

---

## 9. EMAIL VERIFICATION RESTRICTIONS

Unverified users CAN:
  - Log in
  - View their profile
  - See their Member ID
  - Edit display name and mobile
  - Change password

Unverified users CANNOT:
  - Send messages (blocked by Firestore rules: isVerified())
  - Make or receive calls (blocked by Firestore rules)
  - Create conversations

The UI shows a yellow banner on the profile tab with:
  - "Resend" button to resend the verification email
  - "I Verified ✓" button to force-refresh the token and sync the flag

After verifying, the user must either:
  a) Sign out and sign back in, OR
  b) Click "I Verified ✓" (which calls user.reload() and updates Firestore)

---

## 10. ADMIN MODERATION — IMPLEMENTATION NOTES

Admin access requires:
1. Adding the UID to `APP.adminUIDs` array in `js/config.js`
2. Setting the Firebase custom claim: `{ admin: true }` via Admin SDK

Admin capabilities:
  - View all reports with full reporter details
  - Update report status: reviewed / resolved / dismissed
  - Search any user by Member ID and see full profile including email/mobile
  - Suspend accounts (sets `suspended: true` in user doc)
  - Add admin notes to user profiles
  - View complete audit log of all admin actions

Every admin action is logged to `adminAuditLogs` with:
  - adminUid, action, targetId, targetType, reason, timestamp

The audit log is immutable — update and delete are blocked by Firestore rules.

The admin panel is only accessible via the "Admin Panel" button on the profile tab,
which is hidden for non-admin users (`display: none`).

---

## 11. WEBRTC CALLING NOTES

- Calls only work when the recipient is online (isOnline === true).
- Calls only work for email-verified users (enforced by Firestore rules on /calls).
- Signaling uses Firestore /calls/{callId} documents (no external signaling server needed).
- ICE candidates are exchanged via /calls/{callId}/offerCandidates and /answerCandidates.
- STUN servers (Google's free ones) are pre-configured.
- For production cross-network reliability, add a TURN server in WEBRTC_CONFIG.
  Recommended: Twilio TURN (free tier available) or Xirsys.
- Call timeout: 45 seconds (configurable in APP.callTimeoutMs).
- If both users are on the same network (same Wi-Fi), calls will always work.
  TURN is only needed when users are on different NAT networks.

---

## 12. QUICK CLOUDINARY SETUP (Android)

1. Visit https://cloudinary.com on Chrome.
2. Create a free account.
3. Dashboard shows your Cloud Name (top-left, e.g. "djxyz123").
4. Settings → Upload → Upload Presets → Add upload preset.
5. Preset name: sm10x_unsigned
6. Signing Mode: Unsigned
7. Folder: sm10x
8. Save.
9. Paste Cloud Name and preset name into js/config.js.

---

## 13. RECOMMENDED ANDROID APPS FOR DEVELOPMENT

- **Acode** — Code editor with syntax highlighting, file manager
- **Eruda** — In-browser DevTools console (add `<script src="//cdn.jsdelivr.net/npm/eruda"></script>` temporarily)
- **Termux** — Linux terminal for Firebase CLI, git
- **GitHub** (official app) — Push commits, manage secrets
- **Chrome** — Testing the app (supports WebRTC, camera, microphone)

---

## 14. PRODUCTION CHECKLIST

Before going live, verify:
  [ ] All YOUR_* placeholders in config.js replaced with real values
  [ ] YOUR_PROJECT_ID replaced in firebase.json and firebase-deploy.yml
  [ ] Firestore rules deployed (not test mode)
  [ ] Firestore indexes created
  [ ] Cloudinary unsigned preset created
  [ ] Admin UIDs configured
  [ ] Firebase Email/Password auth enabled
  [ ] Email verification working (test with a real email)
  [ ] WebRTC calling tested on two different devices/networks
  [ ] Report system tested (submit a test report, check Firestore)
  [ ] Profile photo upload tested (Cloudinary URL appears in message)
  [ ] Voice note recording tested (hold mic button)
  [ ] HTTPS is enforced (Firebase Hosting does this automatically)
